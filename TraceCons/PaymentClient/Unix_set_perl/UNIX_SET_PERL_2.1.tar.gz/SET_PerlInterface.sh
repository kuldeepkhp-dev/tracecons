#!/bin/sh


# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# Identification:
# $Id: SET_PerlInterface.sh,v 1.5 2000/05/29 05:57:13 jeremym Exp $

# function to be called upon error
onError() {
	echo "SET integration installation discontinued. Please correct above errors first."
	exit 1
}

echo "Q1/14  Enter directory where the Payment Client is installed (eg: /usr/local): "; 
read pcclasspath
if [ "$pcclasspath" = "" ]; then
	pcclasspath="/usr/local"
fi
pcconfig=$pcclasspath/QSIPayments/PaymentClient/config
pcclasspath=$pcclasspath/QSIPayments/PaymentClient/classes

echo "Q2/14  Enter the web server's cgi-bin directory: ";
read cgibindir

echo "Q3/14  Enter the perl executable (eg: /usr/bin/perl): ";
read perlsrcdir
if [ "$perlsrcdir" = "" ]; then
	perlsrcdir="/usr/bin/perl"
fi

echo "Q4/14  Enter the directory where your Payment Client Perl library files reside: ";
read perldir

echo "Q5/14  Please enter the directory where your html files reside: ";
read htmldir

echo "#!"$perlsrcdir > perl/tmp.pl
echo " " >> perl/tmp.pl
cat perl/tmp.pl perl/pcInstallBase.pl > perl/pcInstall.pl

# cleanup the temp files
rm perl/tmp.pl
if [ "$?" != "0" ]; then onError; fi 

# Insert into the newly created /perl/pcInstall the perl and perl source dirs
perl perl/pcInstall.pl $perlsrcdir $perldir 

# move the cgi files into the nominated cgi-bin directory
cp cgi/*.cgi $cgibindir
if [ "$?" != "0" ]; then onError; fi 

# move the .pl files into the qsi perl directory
cp perl/*.pl $perldir
if [ "$?" != "0" ]; then onError; fi 

# move the html files into the web server html file area
cp html/*.html $htmldir
if [ "$?" != "0" ]; then onError; fi 

# Create sbin start paymentclient service
echo "java -cp $pcclasspath PaymentClient.PCService"
echo "#!/bin/sh" > /sbin/PCThread.sh
echo "java -cp $pcclasspath PaymentClient.PCService" >> /sbin/PCThread.sh
chmod 700 /sbin/PCThread.sh
if [ "$?" != "0" ]; then onError; fi 

#remove tmp.dat
rm ./tmp.dat
if [ "$?" != "0" ]; then onError; fi 

echo "Installation of the Perl Payment Client Interface complete."


# Obtain information for the file SetMerchant.config
echo ""
echo "SET Merchant Configuration"

echo "Q6/14  Please enter the Transaction Type for your SET transactions (either Sale or Auth): ";
read trans_type

echo "Q7/14  Enter your Merchant Shop ID (eg 12345678955): ";
read merch_shopid

echo "Q8/14  Enter the host address of your SET helper (ie IP Number or IP Name): "; 
read set_helper_host

echo "Q9/14  Enter the port number of your SET helper (eg 11257): ";
read set_helper_port

echo "Q10/14 Enter the MPOS Wakeup URL (eg http://<domain>:10257/)";
echo "       Please note, you must include a trailing forward-slash (\"/\"): ";
read posurl

echo "Q11/14 Enter the MPOS Transaction URL (eg http://<domain>:257/): "
echo "       Please note, you must include a trailing forward-slash (\"/\"): ";
read pos_main

echo "Q12/14 Enter the URL for SET transactions (eg http://<webserver_domain>/cgi-bin/SET_Transaction.cgi?sessionId=[TRANSID]): "
read set_url

echo "Q13/14 Enter the URL for SET transaction failure notices (eg http://<webserver_domain>/cgi-bin/SET_Receipt_Error.cgi?sessionId=[TRANSID]): "
read failure_url

echo "Q14/14 Enter the URL for SET transaction success notices (eg http://<webserver_domain>/cgi-bin/SET_Receipt.cgi): "
read success_url


#Write SetMerchant.config
echo "Writing $pcconfig/SetMerchant.config"

echo "PAYTYPE=SET" > $pcconfig/SetMerchant.config
echo "TRANS_TYPE=$trans_type" >> $pcconfig/SetMerchant.config
echo "MERCH_SHOPID=$merch_shopid" >> $pcconfig/SetMerchant.config
echo "SET_HELPER_HOST=$set_helper_host" >> $pcconfig/SetMerchant.config
echo "SET_HELPER_PORT=$set_helper_port" >> $pcconfig/SetMerchant.config
echo "POSURL=$posurl" >> $pcconfig/SetMerchant.config
echo "ORDER_DESC_TYPE=text/plain" >> $pcconfig/SetMerchant.config
echo "POS_MAIN=$pos_main" >> $pcconfig/SetMerchant.config
echo "SET_URL=$set_url" >> $pcconfig/SetMerchant.config
echo "FAILURE_URL=$failure_url" >> $pcconfig/SetMerchant.config
echo "SUCCESS_URL=$success_url" >> $pcconfig/SetMerchant.config

# Give this config file the appopriate permissions
chmod 644 $pcconfig/SetMerchant.config
if [ "$?" != "0" ]; then onError; fi 

echo "Done."
echo "Your SET Integration installation is now complete."
