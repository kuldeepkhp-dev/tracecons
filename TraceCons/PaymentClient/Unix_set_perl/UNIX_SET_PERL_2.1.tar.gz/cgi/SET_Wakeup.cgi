#!<<PERL_SRC_DIRECTORY>>
#
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# Identification:
# $Id: SET_Wakeup.cgi,v 1.3 2000/05/09 03:26:08 jeremym Exp $
#
# NAME
# ====
# SET_Wakeup.cgi
#
# PURPOSE
# =======
# Creates a Digital Order and sends it to the Payment Server.
#
# PAYMENT CLIENT VERSION
# ======================
# This module assumes v1.1.54 of the payment client.
#
# REVISION HISTORY
# ================
# v1.0				10 March 2000		Initial version
#
# INPUTS
# ======
#	SessionID			Your (unique) identifier for the transaction
#	MerchantID			Your Merchant ID - issued to you by the payment service or bank
#	PurchaseAmount		Purchase Amount (Cents)
#	Locale			Defines the langauge to use when presenting payment pages
#	ReturnURL			Where to send the Digital Receipt to
#
# OUTPUTS
# =======
#	If no errors detected
#		DigitalOrder	Sent to Payment Server (via browser redirection)
#	Else
#		ErrorCode		Sent to sErrorPage (via browser redirection)
#		Exception		Returns Payment Client Exception (where generated)
#
#	ErrorCode Values
#	================
#	10	Payment Client has not initialised correctly.
#		- Check the installation of the payment client.
#	11	Digital Order has not created correctly.
#		- Check input parameters.
#
# VARIABLES
# =========
#	objPayClient		Payment Client object
#	sDigitalOrder		Digital Order string
#	sErrorPage			Name of Error Handler
#	nErrorCode 			Error Code number
#	sException			Payment Client Exception (where generated)
#	variables			Contains all of the local variables being passed
#
# ==========================================================================
#
# Initialisation
# ==============


	unshift(@INC,'<<PC_PERL_DIRECTORY>>'); # add the qsi Perl dir to find perl stuff


# 	These perl libraries are required to use the mini-rpc mechanism
	require 'PaymentClient.pl';
	require 'url_get.pl';
	
	$merchantConfigFile = '<<SET_MERCH_CONFIG>>';

# 	Output to page header - we are producing an html page
#	print "Content-type: text/html\n\n";

#	Load all the form variables into an associative array
#	=====================================================
# 	If the variables are passed using either GET or
#	POST, extract the variables into $buffer
	if ($ENV{REQUEST_METHOD} eq 'GET') {
 		$buffer = $ENV{'QUERY_STRING'};
	} else {
 		read ( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

# 	Move QUERY_STRING values into $variables
	foreach $pair (split(/&/, $buffer)) {
	 	$pair =~ tr/+//;
		($name, $value) = split(/=/, $pair);
#		convert hex to ascii
		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge;
  		$variables{$name} = "$value";
	}
	
	$enDigitReceipt = $variables{"DR"};
	
	
#	Define the error constants
	#$No_Error 		= 0;
	$Error = 0;
	$ERR_PayClient 	= 10;
	$ERR_SET_Wakeup	= 11;
	$ERR_SET_Status	= 12;
	$ERR_SET_Wakeup_ResultBuffer = 13;

#	Define Error Handler
	$sErrorPage = "SET_Wakeup_Error.cgi";

#	Initialise ErrorCode - set to No Errors
	$nErrorCode = "";
	$sException	= "";	
	

# Create Payment Client Object
# ============================
#	Create Payment Client object
	$objPayClient = new PaymentClient;
#	Open a payment client session
	$sTemp = $objPayClient->open();

#	Test the Payment Client object created corectly
	if ($objPayClient->echo("Test") ne "echo:Test") {
		$nErrorCode = $ERR_PayClient;
	}
	
	
# Decrypt Digital Receipt
# ===================
#	if no errors ...
	if ($nErrorCode == $No_Error) {
		# process the returned encrypted DR string
	    $sTemp = $objPayClient->decryptDigitalReceipt($enDigitReceipt);
	    if ($sTemp eq $Error) {
			# Failed
			$nErrorCode = $ERR_Decrypt;
			$sException = $objPayClient->getResultField("PaymentClient.Error");
		} else {
			# Set ResultField array to Digital Receipt details
			if ($objPayClient->nextResult() eq $Error) {
				# Failed
				$nErrorCode = $ERR_No_Results;
			}
		}
	}	
	
# Extract the fields from the Digital Receipt
# ===========================================
	$CurrencyCode = $objPayClient->getResultField("DigitalReceipt.CurrencyCode");
	$SessionId = $objPayClient->getResultField("DigitalReceipt.SessionId");
	$CurrencyExponent = $objPayClient->getResultField("DigitalReceipt.CurrencyExponent");
	if ($CurrencyExponent > 0) {
    	$CurrencyExponent *= -1;
	}

	$MerchantId = $objPayClient->getResultField("DigitalReceipt.MerchantId");
	$PurchaseAmount = $objPayClient->getResultField("DigitalReceipt.PurchaseAmountInteger");

	$orderDesc = "Retrieve order description from persistent storage using sessionID";
	
# Perform the SETWakeup	
# =====================

	if ($nErrorCode eq "") {
		$sTemp = $objPayClient->doSETWakeupMessageUsingFile($SessionId, $PurchaseAmount,
    		$CurrencyCode, $CurrencyExponent, "This is where the order desc goes", "",
    		$merchantConfigFile);
    		
		if ($sTemp eq $Error) {
			# Failed
			$nErrorCode = $ERR_SET_Wakeup;
			$sException	= $sDigitalOrder;
		} else {
		# Position the result field cursor
			if ($objPayClient->nextResult() eq $Error) {
				# Failed
				$nErrorCode = $ERR_No_Results;
			}
		} 
	}
	
	
# Determine SET Status and continue if OK
# =======================================

	if ($nErrorCode eq "") {
		
		# obtain SET status
		$status = $objPayClient->getResultField("SET.Status");
		
		if ($status ne "OK") {
			$nErrorCode = $ERR_SET_Status;
		}
	}
	
	
	
# Obtain SETWakeup Message 
# ========================

	if ($nErrorCode eq "") {
		
		# obtain SET status
		$wakeupMessage = $objPayClient->getResultFieldBuffer("SET.WakeupMessage");
		
		
		if ($wakeupMessage eq $Error) {
			$nErrorCode = $ERR_SET_Wakeup_ResultBuffer;
		} else {
			# determine length of wakeup message
			$wmLength = length($wakeupMessage);		
		}
		
	}
	
# Payment Client Cleanup
# ======================
	$objPayClient->close();
	
	
# Output appropriate action based upon Error conditions
# =====================================================

	if ($nErrorCode eq "") {
	
# 		convert to binmode for platform independence of stream		
# 		======================================================
		binmode STDOUT;
	
# 		Send SET Wakeup to the Browser - which in turn invokes a SET wallet
# 		===================================================================
		print "Content-type: application/set-payment-initiation\n";
		print "Content-Transfer-Encoding: binary\n";
		print "Content-Length: ".$wmLength."\n";
		print "\n";
		print $wakeupMessage;
	
	} else {
#		Pass control to the error handler
		$sErrorPage = $sErrorPage . "?ErrorCode=" . $nErrorCode;
		$sErrorPage .= "&Exception=" . $sException . $sTemp;
#		Pass control to the Digital Receipt details page
		print "Location:$sErrorPage\n\n";	
	
	}







