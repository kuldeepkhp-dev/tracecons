#!<<PERL_SRC_DIRECTORY>>
#
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# NAME
# ====
# SET_Transaction_Error.cgi
#
# PURPOSE
# =======
# Displays the errors arising from SET_Wakeup.cgi
#
# PAYMENT CLIENT VERSION
# ======================
# 0.61
#
# REVISION HISTORY
# ================
# v1.0				10 March 2000		Initial version
#
# INPUTS
# ======
#	ErrorCode			The value of the error code to display
#	Exception			Returns Payment Client Exception (where generated)
#
# OUTPUTS
# =======
#	None
#
# SUB ROUTINES
# ============
# 	DetermineError		Determine corresponding text for ErrorCode
#	DetermineException	Display Exception (where generated)
#
# ==========================================================================
# Initialisation
# ==============

# Load all the form variables into an associative array, variables
	if ($ENV{REQUEST_METHOD} eq 'GET') {
 		$buffer = $ENV{'QUERY_STRING'};
	} else {
 		read ( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

	foreach $pair (split(/&/, $buffer)) {
	 	$pair =~ tr/+//;
		($name, $value) = split(/=/, $pair);
		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge; # convert hex to ascii
  		$variables{$name} = "$value";
	}
#
# Initialisation
# ==============
	$sErrorCode		= $variables{"ErrorCode"};
	$sException		= $variables{"Exception"};

# Display error
# =============

    print "Content-type: text/html\n\n";
	print "<H1><CENTER>SET Transaction Error</CENTER></H1\n";
	print "<CENTER>\n";
	print "<TABLE>\n";
	print "<TR>	<TD>Error Code</TD>\n";
	print "<TD>$sErrorCode</TD></TR>\n";
	print "<TR>	<TD> &nbsp;</td> <! blank cell ->\n";
	print	"<TD>";
	print DetermineError($sErrorCode);
	print "</TD></TR>\n";
	print "<TR>	<TD> &nbsp;</td> <! blank cell ->";
	print "<TD>";
	print DetermineException($sErrorCode, $sException);
	print "</TD></TR>\n";
	print "<TR><TD></TD>\n";
	print "<TD><BR><BR><BR><A HREF='/SET_Order.html'>New Payment</A></TD></TR>\n";
	print "</TABLE></CENTER>\n";

sub DetermineError {
#
#	ErrorCode Values
#	================
#	10	Payment Client has not initialised correctly.
#		- Check the installation of the payment client.
#	11	Error occurred in call PaymnetClient.doSETTransactionUsingFile
#		- refer to exception and logs
#	12	SETTransaction returned an empty result set
#		- refer to exception and logs
#	13	SETStatus was not successful
#		- refer to logs
#   14 	General Transaction success or failure
#		- refer to logs for point of transaction failure
#	15 	SET Purchase Error 
#		- is this a purchase request
#	16	AcuirerStatus Failure
#	17 	Error obtaining SET merchant transaction id.
#		- check logs
#	18  Invalid SETBufferSize 
#		- check getResultFieldBuffer call
#	19	Method getResultFieldBuffer("SET.Transaction") 
#		- returned a failure result
	
	$ERR_PayClient 	= 10;
	$ERR_SET_Transaction = 11;
	$ERR_No_Results = 12;
	$ERR_SET_Status = 13;
	$ERR_SET_Transaction_Status = 14;
	$ERR_SET_Transaction_Process = 15;
	$ERR_SET_Acquirer_Status = 16;
	$ERR_SET_LIDM = 17;	
	$ERR_SET_BufferSize = 18;
	$ERR_SET_ResultFieldBuffer = 19;


	if ($sErrorCode eq "10") {
		return "Payment Client has not initialised correctly.";
	} elsif ($sErrorCode eq "11") {
		return "SETTransaction returned an error.";
	} elsif ($sErrorCode eq "12") {
		return "SETTransaction returned no results.";
	} elsif ($sErrorCode eq "13") {
		return "SET Status was unsuccesful.";
	} elsif ($sErrorCode eq "14") {
		return "General Transaction Failure - not specifically a SET failure.";
	} elsif ($sErrorCode eq "15") {
		return "SET Purchase error - is this a purchase request.";
	} elsif ($sErrorCode eq "16") {
		return "Error checking Acquirer Status.";
	} elsif ($sErrorCode eq "17") {
		return "Error obtaining SET merchant transaction identifier.";
	} elsif ($sErrorCode eq "18") {
		return "Error SET buffersize invalid.";
	} elsif ($sErrorCode eq "19") {
		return "Error failure returned from method getResultFieldBuffer(SET.Transaction);"		
	} else {
		return "Error unable to be determined.";
	}
}

sub DetermineException {
	if ($sErrorCode eq "11") {
		return $sException;
	}
}

