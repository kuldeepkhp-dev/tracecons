#!<<PERL_SRC_DIRECTORY>>
#
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# NAME
# ====
# SET_Wakeup_Error.cgi
#
# PURPOSE
# =======
# Displays the errors arising from SET_Wakeup.cgi
#
# PAYMENT CLIENT VERSION
# ======================
# 0.61
#
# REVISION HISTORY
# ================
# v1.0				10 March 2000		Initial version
#
# INPUTS
# ======
#	ErrorCode			The value of the error code to display
#	Exception			Returns Payment Client Exception (where generated)
#
# OUTPUTS
# =======
#	None
#
# SUB ROUTINES
# ============
# 	DetermineError		Determine corresponding text for ErrorCode
#	DetermineException	Display Exception (where generated)
#
# ==========================================================================
# Initialisation
# ==============

# Load all the form variables into an associative array, variables
	if ($ENV{REQUEST_METHOD} eq 'GET') {
 		$buffer = $ENV{'QUERY_STRING'};
	} else {
 		read ( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

	foreach $pair (split(/&/, $buffer)) {
	 	$pair =~ tr/+//;
		($name, $value) = split(/=/, $pair);
		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge; # convert hex to ascii
  		$variables{$name} = "$value";
	}
#
# Initialisation
# ==============
	$sErrorCode		= $variables{"ErrorCode"};
	$sException		= $variables{"Exception"};

# Display error
# =============

    print "Content-type: text/html\n\n";
	print "<H1><CENTER>SET Wakeup Error</CENTER></H1\n";
	print "<CENTER>\n";
	print "<TABLE>\n";
	print "<TR>	<TD>Error Code</TD>\n";
	print "<TD>$sErrorCode</TD></TR>\n";
	print "<TR>	<TD> &nbsp;</td> <! blank cell ->\n";
	print	"<TD>";
	print DetermineError($sErrorCode);
	print "</TD></TR>\n";
	print "<TR>	<TD> &nbsp;</td> <! blank cell ->";
	print "<TD>";
	print DetermineException($sErrorCode, $sException);
	print "</TD></TR>\n";
	print "<TR><TD></TD>\n";
	print "<TD><BR><BR><BR><A HREF='/SSL_Order.html'>New Payment</A></TD></TR>\n";
	print "</TABLE></CENTER>\n";

sub DetermineError {
#
#	ErrorCode Values
#	================
#	10	Payment Client has not initialised correctly.
#		- Check the installation of the payment client.
#	11	SET Wakeup Error.
#		- Check input parameters.
#	12 	SET Status Error
#		- status not OK
#	13	SET Wakeup Result Field Buffer Error
#		- error performing getResultFieldBuffer("SET.WakeupMessage");

	$ERR_PayClient 	= 10;
	$ERR_SET_Wakeup	= 11;
	$ERR_SET_Status	= 12;
	$ERR_SET_Wakeup_ResultBuffer = 13;



	if ($sErrorCode eq "10") {
		return "Payment Client has not initialised correctly.";
	} elsif ($sErrorCode eq "11") {
		return "SETWakeup returned an error.";
	} elsif ($sErrorCode eq "12") {
		return "SETWakeup status not OK.";
	} elsif ($sErrorCode eq "13") {
		return "SETWakeup ResultFieldBuffer error.";
	} else {
		return "Error unable to be determined.";
	}
}

sub DetermineException {
	if ($sErrorCode eq "11") {
		return $sException;
	}
}

