#!<<PERL_SRC_DIRECTORY>>
#
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# Identification:
# $Id: SET_Start.cgi,v 1.2 2000/05/09 03:26:07 jeremym Exp $
#
# NAME
# ====
# SET_Start.cgi
#
# PURPOSE
# =======
# Receive a Digital Receipt from the Payment Server; extract and return details.
#
# PAYMENT CLIENT VERSION
# ======================
# This module assumes v1.1.54 of the payment client.
#
# REVISION HISTORY
# ================
# v1.0				10 March 2000		Initial version
#
# INPUTS
# ======
#	DigitalOrder		Received from the Payment Server (via browser redirection)
#
# OUTPUTS
# =======
#	If no errors detected
#		Receipt Details	Sent to DRDetailsURL (via browser redirection)
#		- SessionID
#		- MerchantID
#		- PurchaseAmount
#		- Locale
#		- ReceiptNo		Receipt number - issued by Acquiring bank
#		- TransactionNo
#		- AcqResponseCode	Acquirer Response Code
#		- QSIResponseCode	Summary of Acquirer Response Code
#	Else
#		ErrorCode		Sent to sErrorPage (via browser redirection)
#		Exception		Returns Payment Client Exception (where generated)
#
#	ErrorCode Values
#	================
#	10	Payment Client has not initialised correctly.
#		- Check the installation of the payment client.
#	11	Digital Receipt could not be decrypted
#
#	12	Digital Receipt has not created correctly.
#		- No result.
#
# VARIABLES
# =========
#	objPayClient		Payment Client object
#	enDigitReceipt		Encrypted Digital Receipt
#	sDRDetailsURL		Where to send the Digital Receipt details to
#	sErrorPage			Name of Error Handler
#	nErrorCode 			Error Code number
#	sException			Payment Client Exception (where generated)
#
# ==========================================================================
#
# Initialisation
# ==============
	unshift(@INC,'<<PC_PERL_DIRECTORY>>'); # add the qsi Perl dir to find perl stuff

	require 'PaymentClient.pl';
	require 'url_get.pl';

#	Define the error constants
	$Error = 0;
	$OK = 1;
	$ERR_HTTP = 13;
	

#	Define Error Handler
	$sErrorPage = "./SET_Receipt_Error.cgi";

#	Initialise ErrorCode - set to No Errors
	$nErrorCode = "";
	$sException	= "";

#	Output to page header - we are producing an html page
#	print "Content-type: text/html\n\n";

#	Load all the form variables into an associative array
#	=====================================================
# 	If the variables are passed using either GET or
#	POST, extract the variables into $buffer
	if ($ENV{REQUEST_METHOD} eq 'GET') {
 		$buffer = $ENV{'QUERY_STRING'};
	} else {
  		read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

# 	Move QUERY_STRING values into $variables
	foreach $pair (split(/&/, $buffer)) {
 		$pair =~ tr/+//;
	  	($name, $value) = split(/=/, $pair);
  		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge; # convert hex to ascii
	  	$variables{$name} = "$value";
	}

# Retrieve Digital Receipt
# ======================
	$enDigitReceipt = $variables{"DR"};
	
	if ($enDigitReceipt eq "") {
		$nErrorCode = $ERR_HTTP;
	}
	


# Display the Merchant's "Please Wait" page and a meta refresh to automatically start the transaction
# ===========================
	if ($nErrorCode eq "") {
		
		# Control is passed to the SET_Wakeup.cgi script while the user shown displayed a "merchant defined"
		# page handling the customer experience before-during-after the SET transaction.
		print "Content-type: text/html\n\n";
		print "<html><head>\n";
		print "<script language=\"javascript\">\n";
		print "<\!--\n";
		print "   function openWindow() \n{";
		print "      var w = window.open(\"/cgi-bin/SET_Wakeup.cgi?DR=$enDigitReceipt\", \"temp\", \"width=100, height=100\")\n";
		print "      // w.close();\n";
		print "   \}\n";
		print "// -->\n";
		print "</script>\n";

		print "</head><body onload=\"openWindow()\">";
		print "Thank you for shopping with us.";
		print "<a href=\"/index.htm\">Go here</a> once your transaction is finished. If your transaction does not start in a few seconds,";
		print "<a href=\"/cgi-bin/SET_Wakeup.cgi?DR=".$enDigitReceipt."\">Click here</a>\n";
		print "</body></html>\n";

	} else {
#		Pass control to the error handler
		$sErrorPage = $sErrorPage . "?ErrorCode=" . $nErrorCode;
		$sErrorPage .= "&Exception=" . $sException . $sTemp;
#		Pass control to the Digital Receipt details page
		print "Location:$sErrorPage\n\n";
	}












