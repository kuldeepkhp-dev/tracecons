#!<<PERL_SRC_DIRECTORY>>
#
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# Identification:
# $Id: SET_Receipt_Error.cgi,v 1.1 2000/04/10 03:14:48 simonm Exp $
#
# NAME
# ====
# SET_Receipt_Error.cgi
#
# PURPOSE
# =======
# Displays the error returned by SET_DR.cgi
#
# PAYMENT CLIENT VERSION
# ======================
# This module is not payment client specific.
#
# REVISION HISTORY
# ================
# v1.0				10 March 2000		Initial version
#
# INPUTS
# ======
#	ErrorCode			The value of the error code to display
#	Exception			Returns Payment Client Exception (where generated)
#
# OUTPUTS
# =======
#	None
#
# SUB ROUTINES
# ============
# 	DetermineError		Determine corresponding text for ErrorCode
#	DetermineException	Display Exception (where generated)
#
# ==========================================================================
# Initialisation
# ==============

# Load all the form variables into an associative array, variables
	if ($ENV{REQUEST_METHOD} eq 'GET') {
 		$buffer = $ENV{'QUERY_STRING'};
	} else {
 		read ( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

	foreach $pair (split(/&/, $buffer)) {
	 	$pair =~ tr/+//;
		($name, $value) = split(/=/, $pair);
		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge; # convert hex to ascii
  		$variables{$name} = "$value";
	}
#
# Initialisation
# ==============
	$sErrorCode		= $variables{"ErrorCode"};
	$sException		= $variables{"Exception"};

# Display error
# =============
 	print "Content-type: text/html\n\n";
	print "<H1><CENTER>SET Digital Receipt Error</CENTER></H1\n";
	print "<CENTER>\n";
	print "<TABLE>\n";
	print "<TR>	<TD>Error Code</TD>\n";
	print "<TD>$sErrorCode</TD></TR>\n";
	print "<TR>	<TD> &nbsp;</td> <! blank cell ->\n";
	print	"<TD>";
	print "</TD></TR>\n";
	print "<TR>	<TD> &nbsp;</td> <! blank cell ->";
	print "<TD>";
	&DetermineError;
	&DetermineException;
	print "</TD></TR>\n";
	print "<TR><TD></TD>\n";
	print "<TD><BR><BR><BR><A HREF='/SET_Order.html'>New Payment</A></TD></TR>\n";
	print "</TABLE></CENTER>\n";

sub DetermineError {
#
#	ErrorCode Values
#	================
#	10	Payment Client has not initialised correctly.
#		- Check the installation of the payment client.
#	11	Digital Receipt could not be decrypted.
#
#	12	Digital Receipt has not created correctly.
#		- No result.
#	13	Digital Receipt not found in HTTP values.
#	

	if ($sErrorCode eq "10") {
		print "Payment Client has not initialised correctly.";
	} elsif ($sErrorCode eq "11") {
		print "Digital Receipt could not be decrypted.";
	} elsif ($sErrorCode eq "12") {
		print "Digital Receipt has not created correctly.";
	} elsif ($sErrorCode eq "13") {
		print "Unable to extract DR from HTTP.";
	} else {
		print "Error unable to be determined.";
	}
}

sub DetermineException {
	
	if ($sErrorCode eq "11") {
		print $sException;
	}
}
