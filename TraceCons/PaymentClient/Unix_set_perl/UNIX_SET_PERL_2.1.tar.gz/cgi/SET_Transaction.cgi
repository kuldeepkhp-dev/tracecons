#!<<PERL_SRC_DIRECTORY>>
#
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# Identification:
# $Id: SET_Transaction.cgi,v 1.3 2000/05/09 03:26:08 jeremym Exp $
#
# NAME
# ====
# SET_Wakeup.cgi
#
# PURPOSE
# =======
# Perform the SET Transaction.
#
# PAYMENT CLIENT VERSION
# ======================
# 0.61
#
# INPUTS
# ======
#	SessionID			Your (unique) identifier for the transaction
#	MerchantID			Your Merchant ID - issued to you by the payment service or bank
#	PurchaseAmount		Purchase Amount (Cents)
#	Locale			Defines the langauge to use when presenting payment pages
#	ReturnURL			Where to send the Digital Receipt to
#
# OUTPUTS
# =======
#	If no errors detected
#		DigitalOrder	Sent to Payment Server (via browser redirection)
#	Else
#		ErrorCode		Sent to sErrorPage (via browser redirection)
#		Exception		Returns Payment Client Exception (where generated)
#
#	ErrorCode Values
#	================
#	10	Payment Client has not initialised correctly.
#		- Check the installation of the payment client.
#	11	Digital Order has not created correctly.
#		- Check input parameters.
#
# VARIABLES
# =========
#	objPayClient		Payment Client object
#	sDigitalOrder		Digital Order string
#	sErrorPage			Name of Error Handler
#	nErrorCode 			Error Code number
#	sException			Payment Client Exception (where generated)
#	variables			Contains all of the local variables being passed
#
# ==========================================================================
#
# Initialisation
# ==============


	unshift(@INC,'<<PC_PERL_DIRECTORY>>'); # add the qsi Perl dir to find perl stuff


	require 'PaymentClient.pl';
	require 'url_get.pl';
	
	$merchantConfigFile = '<<SET_MERCH_CONFIG>>';

	
#	Define Error Handler
	$sErrorPage = "SET_Transaction_Error.cgi";

#	Initialise ErrorCode - set to No Errors
	$nErrorCode = "";
	$sException	= "";		
	
	
	
# Load the variables from the POST request into an associativ array
	$envStrings = $ENV{'QUERY_STRING'};

	foreach $pair (split(/&/, $envStrings)) {
 		$pair =~ tr/+//;
  		($name, $value) = split(/=/, $pair);
  		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge; # convert hex to ascii
  		$variables{$name} = "$value";
	}


# set the standard input to binary mode
	binmode STDIN;

# Read the binary stream into the $buffer variable
	read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});

	$true = 1;
	$false = 0;

# Extract the values from the variables associative array
	$sessionID = $variables{"sessionId"};
	$merchantID = $variables{"merchantId"};
	
# determine the length of the buffer
	$contentLength = length($buffer);
 
#	Initialise ErrorCode - set to No Errors
	$nErrorCode = "";
	$sException	= "";	
	


# Create Payment Client Object
# ============================
#	Create Payment Client object
	$objPayClient = new PaymentClient;
#	Open a payment client session
	$sTemp = $objPayClient->open();

#	Test the Payment Client object created corectly
	if ($objPayClient->echo("Test") ne "echo:Test") {
		$nErrorCode = $ERR_PayClient;
	}


# perform the SET Transaction
# ===========================

	if ($nErrorCode eq $No_Error) {
    	$result = $objPayClient->doSETTransactionUsingFile($sessionID, 
    		$merchantConfigFile, $contentLength, $buffer);  

	    if ($result eq $Error) {
			# Failed
			$nErrorCode = $ERR_SET_Transaction;
			$sException = $objPayClient->getResultField("PaymentClient.Error");
		} else {
			# Set ResultField array to Digital Receipt details
			if ($objPayClient->nextResult() eq $Error) {
				# Failed
				$nErrorCode = $ERR_No_Results;
			}
		}
	}
	
# If an error encountered here, stop processing and present the error
# ===================================================================		
	if ($nErrorCode ne "") {
		print "Content-type:  text/html\n\n";
		print "<HTML><TITLE>ERROR</TITLE></HTML><BODY>\n";
    	print "<P>Problem getting nextResult for doSETTransactionUsingFile\n</P>";
		print "</BODY></HTML>";
	}

	
# Determine SET Status and continue if OK
# =======================================
	if ($nErrorCode eq "") {
		# SET Processing Status, "OK" is success, other is error
		$setStatus  = $objPayClient->getResultField("SET.Status");  
		
		
		# If there has been a SET processing error.
		# Record somewhere in a log file and  return an error to the user
		if ($setStatus ne "OK") {
			print "Content-type:  text/html\n\n";
			print "<HTML><TITLE>ERROR</TITLE></HTML><BODY>\n";
			print "A SET Error occurred - Error condition - SET Status: ".$setStatus."\n";
			print "</BODY></HTML>";

			$objPayClient->close();
			exit(-1);
		}
	}                  

# Obtain other field values - the results are not terminal, merely indicators
# of various conditions of the transaction
	$isPurchase = $objPayClient->getResultField("SET.PurchaseStatus");                
	$transactionStatus = $objPayClient->getResultField("SET.TransactionStatus"); 
	
	
# Transaction has been approved by Acquirer
# Record this shopping basket as paid for and ship it out!
# This will happen during the PReq phase of teh SET Transaction
	if ($isPurchase == $true) {
    	# The general transaction processing has failed.
    	# Record in a log and return an error

    	if ($transactionStatus ne "success") {
			# Transaction has failed, record against merchant database
		
			# for more details, investigate acquirerStatus/BankStatus
			$acquirerStatus = $objPayClient->getResultField("SET.AcquirerStatus");
    	} else {
			############################################################
			# DO BASKET PROCESSING HERE	(ie CLEAR THE BASKET, MARK THE #
			# GOODS AS READY TO SHIP ) TRANSACTION HAS BEEN APPROVED   #
			# BY THE ACQUIRER.                                         #
			############################################################
    
			# obtain the SET merchant Transaction Identifier for recording purposes
			# =====================================================================
    		$lidm = $objPayClient->getResultField("SET.LIDM");
    	}
	}


# Send all the results back to the wallet
# =======================================
	$outBuf = $objPayClient->getResultFieldBuffer("SET.Transaction");
	$outBufSize = length($outBuf);

	# Test the size of the outBuffer
	if (length($outBuf) <= 0) {
		print "Content-type: text/html\n\n";
		print "<HTML><BODY>";
		print "<P>Problem with getResultFieldBuffer\n</P></BODY>";
		print "</HTML>";
    	$objPayClient->close();
		exit(-1);
	}


# write out the returned binary SET data back to the SET Wallet
# =============================================================
	binmode STDOUT;

	print "Content-type: application/set-payment\n";
	print "Content-Transfer-Encoding: binary\n";
	print "Content-Length: ".$outBufSize."\n";
	print "\n";
	print $outBuf;
	
# cleanup
# =======

	$objPayClient->close();
	exit(-1);	

