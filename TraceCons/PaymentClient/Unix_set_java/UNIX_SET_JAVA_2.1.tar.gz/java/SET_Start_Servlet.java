/*
 * Copyright 1999 QSI Payments, Inc.
 * All rights reserved.  This precautionary copyright notice against
 * inadvertent publication is neither an acknowledgement of publication,
 * nor a waiver of confidentiality.
 *
 * Identification:
 *	$Id: SET_Start_Servlet.java,v 1.1 2000/04/27 00:44:07 simonm Exp $
 *
 * Description:
 *      Example Payment Client Servlet that accepts an encrypted digital receipt
 *      and initiates the SET Wakeup stage of the SET process.
 *
 */

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import PaymentClient.*;

/**
 *	@author		SimonM
 *	@version	$Revision: 1.1 $
 */
public class SET_Start_Servlet extends HttpServlet {

    static public String   CVS_ID = "@(#)$Id: SET_Start_Servlet.java,v 1.1 2000/04/27 00:44:07 simonm Exp $";

    // define error handling variables
    private String errorBodyText = null;
    private ErrorPage errorPage = null;

    /* ========================================================================
     * Methods
     */

    /**
     * doGet - Perform a HTTP GET Operation
     *
     * @param req   HTTP Request Information
     * @param res   HTTP Response Information
     *
     * @exception ServletException
     * @exception IOException
     */
    public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        // extract the encrypted DR from the HTTP
        String encDR = req.getParameter("DR");

        if (encDR.equals("")) {
            errorPage.display("SET_Start_Servlet_Error",
                "SET Start Servlet Error", "Digital Receipt from HTTP was empty");
        } else {
            // Display the Merchant's "Please Wait" page and a meta refresh to
            // automatically start the transaction

		    // Control is passed to the SET_Wakeup_Servlet script while the
            // user is shown displayed a "merchant defined" page handling the
            // customer experience before-during-after the SET transaction.

            // prepare the output stream - ie the HTML response writer
            res.setContentType("text/html\n\n");
            PrintWriter out = res.getWriter();

		    out.println("<html><head>");
            out.println("<script language=\"javascript\">");
            out.println("<!--");

            out.println("function setCookie(name, value, timeout) {");
            out.println("var thirtyFiveSecs = 35000");
            out.println("var expDate = new Date()");
            out.println("expDate.setTime(expDate.getTime() + thirtyFiveSecs)");
            out.println("document.cookie = name + \"=\" + escape(value) +" +
                " \"; expires=\" + expDate.toGMTString()");
            out.println("}");

            out.println("function redirect() {");
            out.println("  if (document.cookie.indexOf(\"walletPage=true\") < 0) {");
            out.println("    setCookie(\"walletPage\",\"true\")");
            out.println("    window.open(\"/servlet/SET_Wakeup_Servlet?DR=" +
                encDR + "\")");

            out.println("  }");
            out.println("}");
            out.println("//-->");
            out.println("</script>");

            out.println("</head><body onload=\"redirect();\">");
            out.println("Thank you for shopping with us.");
            out.println("<a href=\"/Java_SET_Order.html\">Go here</a> once your " +
                "transaction is finished. If your transaction does not " +
                "start in a few seconds,");
            out.println("<a href=\"/servlet/SET_Wakeup_Servlet?DR=" +
                encDR + "\">Click here</a>");
            out.println("</body></html>");
        }
    }

    /**
     * doPost - Perform a HTTP POST Operation
     *
     * @param req	HTTP Request Information
     * @param res       HTTP Response Information
     *
     * @exception ServletException
     * @exception IOException
     */
    public void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        doGet(req, res);   // Chain POST requests to
    }

}