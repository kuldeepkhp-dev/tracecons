/*
 * Copyright 1999 QSI Payments, Inc.
 * All rights reserved.  This precautionary copyright notice against
 * inadvertent publication is neither an acknowledgement of publication,
 * nor a waiver of confidentiality.
 *
 * Identification:
 *	$Id: SET_DO_Servlet.java,v 1.1 2000/04/27 00:44:06 simonm Exp $
 *
 * Description:
 *      Example Payment Client Servlet that creates a digital order and sends
 *      it to the Payment Server. If errors occur in process, an error
 *      page displays a stack trace to expedite correction.
 */

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import PaymentClient.*;

/**
 *  Example Payment Client Servlet of creating a Digital Order
 *
 *	@author		SimonM
 *	@version	$Revision: 1.1 $
 */
public class SET_DO_Servlet extends HttpServlet {

    static public String   CVS_ID = "@(#)$Id: SET_DO_Servlet.java,v 1.1 2000/04/27 00:44:06 simonm Exp $";

    /* ========================================================================
     *
     * Methods
     */

    /**
     * doGet - Perform a HTTP GET Operation
     *
     * @param req	HTTP Request Information
     * @param res       HTTP Response Information
     *
     * @exception ServletException
     * @exception IOException
     */
    public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        try {
            // Extract Parameters from HTTP request
            String sessionId = req.getParameter("SessionID");
            String merchantId = req.getParameter("MerchantID");
            int amount = Integer.parseInt(req.getParameter("PurchaseAmount"));
            String localeId = req.getParameter("Locale");
            String returnURL = req.getParameter("ReturnURL");

            // Create a Payment Client Object
            PaymentClientImpl paymentClient = new PaymentClientImpl();

            // Get The digitalOrder
            String digitalOrder =
                paymentClient.getDigitalOrder(sessionId, merchantId,
                amount, localeId, returnURL);

            // Serve redirect page - this sends the customer to the
            // payment server page
            res.sendRedirect(digitalOrder);
        } catch (Exception ex) {
            //displayErrorPage(res, ex);
            ErrorPage errorPage = new ErrorPage(ex, res);
            errorPage.display("SET_DO_Servlet_Error",
                "Problem Creating Digital Order", ex.getMessage());
	    }
    }

    /**
     * doPost - Perform a HTTP POST Operation
     *
     * @param req	HTTP Request Information
     * @param res       HTTP Response Information
     *
     * @exception ServletException
     * @exception IOException
     */
    public void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        doGet(req, res);   // Chain POST requests to
    }

}