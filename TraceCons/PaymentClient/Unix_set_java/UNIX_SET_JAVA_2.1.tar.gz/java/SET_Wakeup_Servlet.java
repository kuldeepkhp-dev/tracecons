/*
 * Copyright 1999 QSI Payments, Inc.
 * All rights reserved.  This precautionary copyright notice against
 * inadvertent publication is neither an acknowledgement of publication,
 * nor a waiver of confidentiality.
 *
 * Identification:
 *	$Id: SET_Wakeup_Servlet.java,v 1.1 2000/04/27 00:44:07 simonm Exp $
 *
 * Description:
 *      Example Payment Client Servlet that accepts an encrypted digital receipt
 *      and invokes the SET wallet that subsequently performs the SET transaction.
 *
 */

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import PaymentClient.*;
import QSI.util.*;

/**
 *	@author		SimonM
 *	@version	$Revision: 1.1 $
 */
public class SET_Wakeup_Servlet extends HttpServlet {

    static public String   CVS_ID = "@(#)$Id: SET_Wakeup_Servlet.java,v 1.1 2000/04/27 00:44:07 simonm Exp $";

    // set the merchant configuration file
    static private String relativeMerchantConfigFile =
        "/PaymentClient/config/SetMerchant.config";

    // initialize some member variables
    private PaymentClientImpl m_paymentClient = null;
    private HttpServletResponse m_httpServletResponse = null;

    // define error handling variables
    private String errorBodyText = null;
    private ErrorPage errorPage;

    /* ========================================================================
     * Methods
     */



    /**
     * doGet - Perform a HTTP GET Operation
     *
     * @param req   HTTP Request Information
     * @param res   HTTP Response Information
     *
     * @exception ServletException
     * @exception IOException
     */
    public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        // set the member value m_httpServletResponse
        m_httpServletResponse = res;

        try {
            // Step 1. Extract  the encrypted Digital Receipt from the request
            String encDR = req.getParameter("DR");

            // Step 2. Create a Payment Client Object
            m_paymentClient = new PaymentClientImpl();

            // Step 3. Decrypt the encDR - an exception is thrown if not true
            if (m_paymentClient.decryptDigitalReceipt(encDR)) {

                // Access the result fields
                if (m_paymentClient.nextResult()) {
                    performSETWakeup();
                } else {
                    displayError(null, "PaymentClient.nextResult Error");
                }
            }
        } catch (Exception ex) {
            displayError(ex, ex.getMessage());
    	}
    }

    /**
     * doPost - Perform a HTTP POST Operation
     *
     * @param req	HTTP Request Information
     * @param res       HTTP Response Information
     *
     * @exception ServletException
     * @exception IOException
     */
    public void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        doGet(req, res);   // Chain POST requests to
    }

    /**
     * Performs the SET wakeup method of the PaymentCLient after extracting the
     * parameters of the Digital receipt. All errors are handled by sending the
     * error message to th displayError method.
     *
     * @exception exception
     *      thrown back to calling method
     */
    private void performSETWakeup() throws Exception {

        // determine the location of the merchant config file
        File fileBase = AppContext.getRootDir();


        String merchantConfigFile = fileBase.getPath() +
            relativeMerchantConfigFile;

        // extract the fields from the Digital Receipt
        String currencyCode =
            m_paymentClient.getResultField("DigitalReceipt.CurrencyCode");
        String sessionId =
            m_paymentClient.getResultField("DigitalReceipt.SessionId");

        String currencyExponent =
            m_paymentClient.getResultField("DigitalReceipt.CurrencyExponent");
        int currExponent = Integer.parseInt(currencyExponent);

        // the currency exponent should be negative - just ensure that it is
        if (currExponent > 0) {
            currExponent *= -1;
        }
        currencyExponent = String.valueOf(currExponent);

        String merchantId =
            m_paymentClient.getResultField("DigitalReceipt.MerchantId");

        int purchaseAmount =
            Integer.parseInt(m_paymentClient.getResultField(
                "DigitalReceipt.PurchaseAmountInteger"));

        String orderDesc = "Retrieve order description from " +
            "persistent storage using sesisonID";


        // make the wakeup call using the extracted parameters
        if (m_paymentClient.doSETWakeupMessageUsingFile(sessionId,
            purchaseAmount, currencyCode, currencyExponent,
            "This is where the order description goes", "", merchantConfigFile)) {

            // prepare the result set for access
            if (m_paymentClient.nextResult()) {
                // check the status of the Transaction to date
                if (m_paymentClient.getResultField("SET.Status").equals("OK")) {
                    byte[] wakeupMessage =
                        m_paymentClient.getResultFieldBuffer("SET.WakeupMessage");

                    if (wakeupMessage != null) {
                        invokeWallet(wakeupMessage);
                    } else {
                        displayError(null, "getresultFieldBuffer returned a " +
                            "null wakeup message");
                    }
                } else {
                    displayError(null, "SET.Status not OK");
                }
            } else {
                displayError(null, "PaymentClient.nextResult Error " +
                    "for doSETWakeupMessage");
            }

        } else {
            displayError(null, "PaymentClient.doSETWakeupMessageUsingFile Error");
        }
    }

    /**
     * Send SET Wakeup to the Browser - which in turn invokes a SET wallet.
     * This method has to account for the binary messaging that is part of SET.
     *
     * @param wakeupMessage
     *      the encoded string that invokes the wallet to initiate the SET
     *      transaction.
     */
    private void invokeWallet(byte[] wakeupMessage) throws IOException {
        // prepare the output stream - ie the ServletOutputStream for binary
        m_httpServletResponse.setContentType("application/set-payment-initiation");
        m_httpServletResponse.setHeader("Content-Transfer-Encoding", "binary");
        m_httpServletResponse.setContentLength(wakeupMessage.length);

        ServletOutputStream out = m_httpServletResponse.getOutputStream();
        out.write(wakeupMessage);
    }

    /**
     * Takes the supplied error message and creates an error page that it
     * subsequently displays using the errorPage class.
     *
     * @param exception
     *      the exception situation that has been raised - can be null if the
     *      error has not been generated via an exception
     * @param errorMessage
     *      the message to dispay in the body of the error page
     */
     private void displayError(Exception ex, String errorMessage)
        throws IOException {

        // reset any previously instantiated error pages
        errorPage = null;

        // create a new error page instance
        errorPage = new ErrorPage(ex, m_httpServletResponse);

        errorPage.display("SET_Wakeup_Servlet_Error",
            "SET Wakeup Servlet Error", errorMessage);
     }

}