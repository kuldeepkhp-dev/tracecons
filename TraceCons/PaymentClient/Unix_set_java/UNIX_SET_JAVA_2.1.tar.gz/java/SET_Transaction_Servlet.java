/*
 * Copyright 1999 QSI Payments, Inc.
 * All rights reserved.  This precautionary copyright notice against
 * inadvertent publication is neither an acknowledgement of publication,
 * nor a waiver of confidentiality.
 *
 * Identification:
 *	$Id: SET_Transaction_Servlet.java,v 1.2 2000/05/05 06:25:50 simonm Exp $
 *
 * Description:
 *      Example Payment Client Servlet that performs the SET transaction
 *      part of the SET transaction process.
 *
 */

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import PaymentClient.*;
import QSI.util.*;

/**
 *	@author		SimonM
 *	@version	$Revision: 1.2 $
 */
public class SET_Transaction_Servlet extends HttpServlet {

    static public String   CVS_ID = "@(#)$Id: SET_Transaction_Servlet.java,v 1.2 2000/05/05 06:25:50 simonm Exp $";

    // set the relative merchant configuration file
    static private String relativeMerchantConfigFile =
        "/PaymentClient/config/SetMerchant.config";


    // initialize some member variables
    private PaymentClientImpl m_paymentClient = null;
    private HttpServletResponse m_httpServletResponse = null;

    // define error handling variables
    private String errorBodyText = null;
    private ErrorPage errorPage = null;

    /* ========================================================================
     * Methods
     */

    /**
     * doGet - Perform a HTTP GET Operation
     *
     * @param req   HTTP Request Information
     * @param res   HTTP Response Information
     *
     * @exception ServletException
     * @exception IOException
     */
    public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {
        //
    }

    /**
     * doPost - Perform a HTTP POST Operation
     *
     * @param req	HTTP Request Information
     * @param res       HTTP Response Information
     *
     * @exception ServletException
     * @exception IOException
     */
    public void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {

        // determine the location of the merchant config file
        File fileBase = AppContext.getRootDir();
        String merchantConfigFile = fileBase.getPath() +
            relativeMerchantConfigFile;


        // set the member value m_httpServletResponse
        m_httpServletResponse = res;

        try {
            // Extract pertinent values from the http stream
            String sessionId = req.getParameter("sessionId");
            String merchantId = req.getParameter("merchantId");

            // Create a Payment Client Object
            m_paymentClient = new PaymentClientImpl();

            // Read the binary stream into the reqBuffer variable
            byte[] reqBuffer = new byte[req.getContentLength()];
            req.getInputStream().read(reqBuffer);

            if (m_paymentClient.doSETTransactionUsingFile(sessionId, reqBuffer,
                req.getContentLength(), merchantConfigFile)) {

                processTransaction();
            } else {
                displayError(null, "doSETTransactionUsingFile method error");
            }

        } catch (Exception ex) {
            displayError(ex, ex.getMessage());
    	}
    }

    /**
     * handles the subsequent messaging after a successful call to the
     * doSETTransaction method.
     *
     * @exception exception
     *      thrown back to calling method
     */
    private void processTransaction() throws Exception {
        // the call to setTransaction has been successful, therefore process the
        // output

        if (m_paymentClient.nextResult()) {

        	// These are the status fields available
            String transactionStatus =
                m_paymentClient.getResultField("SET.TransactionStatus");
            String setStatus =
                m_paymentClient.getResultField("SET.Status");
        	String purchaseStatus =
                m_paymentClient.getResultField("SET.PurchaseStatus");
        	String acquirerStatus =
                m_paymentClient.getResultField("SET.AcquirerStatus");

        	// First check to see if the SET Transmssion status is ok
        	if (!setStatus.equalsIgnoreCase("OK")) {
                // let wallet display error condition - not a Payment Client or
                // servlet error
        	    return;
        	}

        	// Now check the overall transaction status
        	if (transactionStatus.equalsIgnoreCase("success")) {
        		// We would do processing here to indicate that the shopping basket
        		// is ready to ship since the transaction was successful at the bank
        	} else {
        	    // If it's in the purchase stage of the transaction and it's failed
        		// we can get the status from the bank as to why it failed
        		if (purchaseStatus.equals("1")) {
        			// We could record the reason why it was rejected by the bank
        		    String reasonRejected = acquirerStatus;
                    // error will manifest in SET wallet - do not handle with the
                    // displayError method of this class, or it will interfere
                    // with the SET messaging
        		}
        	}

           	byte[] bodyOut = m_paymentClient.getResultFieldBuffer("SET.Transaction");
            returnToWallet(bodyOut);
        } else {
            displayError(null, "setTransactionUsingFile.nextResult error");
        }
    }

    /**
     * send results back to the SET Wallet as long as the buffer exists
     *
     * @exception IOException
     *      on Input/Output Exception
     */
     private void returnToWallet(byte[] bodyOut) throws IOException {

        if (bodyOut.length > 0) {
            // prepare the output stream - ie the ServletOutputStream for binary
            m_httpServletResponse.setContentType("application/set-payment");
            m_httpServletResponse.setHeader("Content-Transfer-Encoding", "binary");
            m_httpServletResponse.setHeader("Content-Length", String.valueOf(bodyOut.length));

            ServletOutputStream out = m_httpServletResponse.getOutputStream();
            out.write(bodyOut, 0, bodyOut.length);
        } else {
		    displayError(null, "Problem with getResultFieldBuffer - length is zero");
	    }
    }


    /**
     * This method is used to display error conditions that arise from exceptions
     * or erroneous situations within the Payment Client and this servlet.
     * Actual SET errors originating from SET infrastructure will manifest itself
     * in the SET wallet. This method takes the supplied error message and
     * creates an error page that is subsequently displayed using the ErrorPage
     * class.
     *
     * @param exception
     *      the exception situation that has been raised - can be null if the
     *      error has not been generated via an exception
     * @param errorMessage
     *      the message to dispay in the body of the error page
     */
     private void displayError(Exception ex, String errorMessage)
        throws IOException {

        // reset any previously instantiated error pages
        errorPage = null;

        // create a new error page instance
        errorPage = new ErrorPage(ex, m_httpServletResponse);

        errorPage.display("SET_Transaction_Servlet_Error",
            "SET Transaction Servlet Error", errorMessage);
     }
}