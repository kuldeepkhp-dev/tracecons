#!/bin/sh

# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# Identification:
# $Id: PerlInterface.sh,v 1.5 2000/05/29 05:57:13 jeremym Exp $

# function to be called upon error
onError() {
	echo "Integration installation discontinued. Please correct above errors first."
	exit 1
}

echo "Enter directory where the Payment Client is installed (eg: /usr/local)"; 
read pcclasspath
if [ "$pcclasspath" = "" ]; then
	pcclasspath="/usr/local"
fi
pcclasspath=$pcclasspath/QSIPayments/PaymentClient/classes

echo "Enter the web server's cgi-bin directory: ";
read cgibindir

echo "Enter the perl executable (eg: /usr/bin/perl): ";
read perlsrcdir
if [ "$perlsrcdir" = "" ]; then
	perlsrcdir="/usr/local"
fi

echo "Enter the directory where your Payment Client Perl library files reside: ";
read perldir

echo "Please enter the directory where your html files reside: ";
read htmldir

echo "#!"$perlsrcdir > perl/tmp.pl
echo " " >> perl/tmp.pl
cat perl/tmp.pl perl/pcInstallBase.pl > perl/pcInstall.pl

# cleanup the temp files
rm perl/tmp.pl
if [ "$?" != "0" ]; then onError; fi 

# Insert into the newly created /perl/pcInstall the perl and perl source dirs
perl perl/pcInstall.pl $perlsrcdir $perldir 

# move the cgi files into the nominated cgi-bin directory
cp cgi/*.cgi $cgibindir
if [ "$?" != "0" ]; then onError; fi 

# move the .pl files into the qsi perl directory
cp perl/*.pl $perldir
if [ "$?" != "0" ]; then onError; fi 

# move the html files into the web server html file area
cp html/*.html $htmldir
if [ "$?" != "0" ]; then onError; fi 

# Create sbin start paymentclient service
echo "java -cp $pcclasspath PaymentClient.PCService"
echo "#!/bin/sh" > /sbin/PCThread.sh
echo "java -cp $pcclasspath PaymentClient.PCService" >> /sbin/PCThread.sh
chmod 700 /sbin/PCThread.sh
if [ "$?" != "0" ]; then onError; fi 

#remove tmp.dat
rm ./tmp.dat
if [ "$?" != "0" ]; then onError; fi 

echo "Installation of the Perl Payment Client Interface complete"


