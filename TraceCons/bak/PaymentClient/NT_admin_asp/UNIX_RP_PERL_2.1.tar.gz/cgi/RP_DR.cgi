#!<<PERL_SRC_DIRECTORY>>
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# NAME
# ====
# RP_DR.cgi
#
# PURPOSE
# ======= 
# Receive a Digital Receipt from the Payment Server; extract and return details.
#
# PAYMENT CLIENT VERSION
# ======================
# This module assumes v1.1.54 of the payment client.
#
# REVISION HISTORY
# ================
# v0.1			20 January 1999		Initial version
#
# INPUTS
# ======
#	DigitalOrder	Received from the Payment Server (via browser redirection)
#
# OUTPUTS
# =======
#	If no errors detected
#		Receipt Details	Sent to DRDetailsURL (via browser redirection)
#		- SessionID
#		- MerchantID
#		- PurchaseAmount
#		- LocaleID
#		- ReceiptNo		Receipt number - issued by Acquiring bank
#		- TransactionNo
#		- AcqResponseCode	Acquirer Response Code
#		- QSIResponseCode	Summary of Acquirer Response Code
#	Else
#		ErrorCode		Sent to sErrorPage (via browser redirection)
#		Exception		Returns Payment Client Exception (where generated)
#
#	ErrorCode Values
#	================
#	10	Payment Client has not initialised correctly.
#		- Check the installation of the payment client.
#	11	Digital Receipt could not be decrypted
#
#	12	Digital Receipt has not created correctly.
#		- No result.
#
#
# VARIABLES
# =========
#	objPayClient		Payment Client object
#	enDigitReceipt		Encrypted Digital Receipt
#	sDRDetailsURL		Where to send the Digital Receipt details to
#	sErrorPage			Name of Error Handler
#	nErrorCode 			Error Code number
#	sException			Payment Client Exception (where generated)
#
# ==========================================================================
#
# Initialisation
# ==============
	unshift(@INC,'<<PC_PERL_DIRECTORY>>'); # add the qsi Perl dir to find perl stuff

	require 'PaymentClient.pl';
	require 'url_get.pl';

#	Define the error constants
	$Error = 0;
	$OK = 1;
	$ERR_PayClient 	= 10;
	$ERR_Decrypt	= 11;
	$ERR_No_Results	= 12;

#	Initialise ErrorCode - set to No Errors
	$nErrorCode = "";
	$sException	= "";

#	Define Error Handler
	$sErrorPage = "./RP_Receipt_Error.cgi";

#	Define module to receive Digital Receipt details
	$sDRDetailsURL = "./RP_Receipt.cgi";

#	Load all the form variables into an associative array
#	=====================================================
# 	If the variables are passed using either GET or
#	POST, extract the variables into $buffer
	if ($ENV{REQUEST_METHOD} eq 'GET') {
 		$buffer = $ENV{'QUERY_STRING'};
	} else {
  		read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

# 	Move QUERY_STRING values into $variables
	foreach $pair (split(/&/, $buffer)) {
 		$pair =~ tr/+//;
	  	($name, $value) = split(/=/, $pair);
  		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge; # convert hex to ascii
	  	$variables{$name} = "$value";
	}

# Retrieve Digital Order
# ======================
	$enDigitReceipt = $variables{"DR"};

# Create Payment Client Object
# ============================
#	Create Payment Client object
	$objPayClient = new PaymentClient;
#	Open a payment client session
	$sTemp = $objPayClient->open();

#	Test the Payment Client object created corectly
	if ($objPayClient->echo("Test") ne "echo:Test") {
		$nErrorCode = $ERR_PayClient;
	}

# Get Digital Receipt
# ===================
#	if no errors ...
	if ($nErrorCode eq "") {
		# process the returned encrypted DR string
	    $sTemp = $objPayClient->decryptDigitalReceipt($enDigitReceipt);
	    if ($sTemp eq $Error) {
			# Failed
			$nErrorCode = $ERR_Decrypt;
			$sException = $objPayClient->getResultField("PaymentClient.Error");
		} else {
			# Set ResultField array to Digital Receipt details
			if ($objPayClient->nextResult() eq $Error) {
				# Failed
				$nErrorCode = $ERR_No_Results;
			}
		}
	}


# Get Digital Receipt details
# ===========================
#	if no errors ...
	if ($nErrorCode eq "") {
#		Gather Digital Receipt variables and append to Digital Receipt Details URL
		$sDRDetailsURL .= "?SessionID=" 		. $objPayClient->getResultField("DigitalReceipt.SessionId");
		$sDRDetailsURL .= "&MerchantID=" 		. $objPayClient->getResultField("DigitalReceipt.MerchantId");
		$sDRDetailsURL .= "&PurchaseAmount=" 	. $objPayClient->getResultField("DigitalReceipt.PurchaseAmountInteger");
		$sDRDetailsURL .= "&Locale=" 			. $objPayClient->getResultField("DigitalReceipt.Locale");
		$sDRDetailsURL .= "&ReceiptNo=" 		. $objPayClient->getResultField("DigitalReceipt.ReceiptNo");
		$sDRDetailsURL .= "&TransactionNo=" 	. $objPayClient->getResultField("DigitalReceipt.TransactionNo");
		$sDRDetailsURL .= "&AcqResponseCode=" 	. $objPayClient->getResultField("DigitalReceipt.AcqResponseCode");
		$sDRDetailsURL .= "&QSIResponseCode=" 	. $objPayClient->getResultField("DigitalReceipt.QSIResponseCode");

#		Finished with the $objPayClient object, so nullify it
		$objPayClient->close();

#		Pass control to the Digital Receipt details page
		print "Location:$sDRDetailsURL\n\n";
	} else {
#		Finished with the objPayClient object, so nullify it
		$objPayClient->close();

#		Pass control to the error handler
		$sErrorPage = $sErrorPage . "?ErrorCode=" . $nErrorCode;
		$sErrorPage .= "&Exception=" . $sException . $sTemp;
#		Pass control to the Digital Receipt details page
		print "Location:$sErrorPage\n\n";
	}












