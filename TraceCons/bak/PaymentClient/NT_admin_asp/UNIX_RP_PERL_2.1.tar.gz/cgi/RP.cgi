#!<<PERL_SRC_DIRECTORY>>
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# NAME
# ====
# RP.cgi
#
# PURPOSE
# =======
# Creates a Digital Order and sends it to the Payment Server.
# The Payment Server replies with the Digital Receipt.
#
# PAYMENT CLIENT VERSION
# ======================
# This module assumes v1.1.54 of the payment client.
#
# REVISION HISTORY
# ================
# v0.1				20 January 2000		Initial version
#
# INPUTS
# ======
#	SessionID			Your (unique) identifier for the transaction
#	MerchantID			Your Merchant ID - issued to you by the payment service or bank
#	PurchaseAmount		Purchase Amount (Cents)
#	Locale			Defines the langauge to use when presenting payment pages
#					Not used for MOTO, but required for consistency with SSL+
#	ccNumber			Credit Card number
#	ccExpiry			Credit Card Expiry Date (YYMM)
#
# OUTPUTS 
# =======
#	If no errors detected
#		Receipt Details	Sent to DRDetailsURL (via browser redirection)
#		- SessionID
#		- MerchantID
#		- PurchaseAmount
#		- Locale
#		- ReceiptNo		Receipt number - issued by Acquiring bank
#		- TransactionNo
#		- AcqResponseCode	Acquirer Response Code
#		- QSIResponseCode	Summary of Acquirer Response Code
#	Else
#		ErrorCode		Sent to sErrorPage (via browser redirection)
#		Exception		Returns Payment Client Exception (where generated)
#
#	ErrorCode Values
#	================
#	10	Payment Client has not initialised correctly.
#		- Check the installation of the payment client.
#	11	Digital Order has not created correctly.
#		- Check input parameters.
#	12	Digital Receipt has not created correctly.
#		- No result.
#
#
# VARIABLES
# =========
#	objPayClient		Payment Client object
#	sDRDetailsURL		Where to send the Digital Receipt details to
#	sErrorPage			Name of Error Handler
#	nErrorCode 			Error Code number
#	sException			Payment Client Exception (where generated)
#	sTemp				Temporary variable
#
# ==========================================================================
#
# Initialisation
# ==============
	unshift(@INC,'<<PC_PERL_DIRECTORY>>'); # add the qsi Perl dir to find perl stuff

	require 'PaymentClient.pl';
	
#	Define the error constants
	$Error= 0;
	$OK = 1;
	$ERR_PayClient 	= 10;
	$ERR_DigitalOrder	= 11;
	$ERR_No_Results	= 12;


#	Initialise ErrorCode - set to No Errors
	$nErrorCode = "";
	$sException	= "";

#	Define Error Handler
	$sErrorPage = "./RP_PayAgain_Error.cgi";

#	Define module to receive Digital Receipt details
	$sDRDetailsURL = "./RP_Receipt.cgi";

# 	Output to page header - we are producing an html page
#	print "Content-type: text/html\n\n";

#	Load all the form variables into an associative array
#	=====================================================
# 	If the variables are passed using either GET or
#	POST, extract the variables into $buffer
	if($ENV{REQUEST_METHOD} eq 'GET') {
		$buffer=$ENV{'QUERY_STRING'};
	} else {
		read ( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

# 	Move QUERY_STRING values into $variables
	foreach $pair (split(/&/, $buffer)) {
		$pair =~ tr/+//;
		($name, $value) = split(/=/, $pair);
		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge; # convert hex to ascii
		$variables{$name}="$value";
	}



# Extract variables
# =================
	$sSessionID		= $variables{"SessionID"};
	$sMerchantID	= $variables{"MerchantID"};
	$sPurchaseAmount	= $variables{"PurchaseAmount"};
	$sLocale		= $variables{"Locale"};
	$sccNumber		= $variables{"ccNumber"};
	$sccExpiry		= $variables{"ccExpiry"};
	$sTransactionNo	= $variables{"TransactionNo"};

# Create Payment Client Object
# ============================
#	Create Payment Client object
	$objPayClient = new PaymentClient;
# 	Open a payment client session
	$sTemp = $objPayClient->open();

#	Test the Payment Client object created corectly
	if ($objPayClient->echo("Test") ne "echo:Test") {
		$nErrorCode = $ERR_PayClient;
	}

# Generate and Send Digital Order
# ===============================
# 	if no errors ...
	if ($nErrorCode eq "") {
#	 	if recurring payment add transaction number
		if ($sTransactionNo != "") {
#			Add Transaction number to Digital Order
			$sTemp = $objPayClient->addDigitalOrderField("RecurRefTXNo", $sTransactionNo);
		} else {
#			Add credit card fields to Digital Order
			$sTemp = $objPayClient->addDigitalOrderField("CardNum", $sccNumber);
			$sTemp = $objPayClient->addDigitalOrderField("CardExp", $sccExpiry);
		}

#		Generate and Send Digital Order (& receive Digital Receipt)
#		===========================================================
		$sBlankValue	= "";
		$sTemp = $objPayClient->sendMOTODigitalOrder($sSessionID, $sMerchantID, $sPurchaseAmount, $sLocale, $sBlankValue);

		if ($sTemp eq $Error) {
#			Failed
			$nErrorCode = $ERR_DigitalOrder;
			$sException	= $objPayClient->getResultField("PaymentClient.Error");
		} else {
#			Position the result field cursor
			if ($objPayClient->nextResult() eq $Error) {
#				Failed
				$nErrorCode = $ERR_No_Results;
			}
		}
	}

# Get Digital Receipt details
# ===========================
# if no errors ...
	if ($nErrorCode eq "") {
#		Gather Digital Receipt variables and append to Digital Receipt Details URL
		$sDRDetailsURL = $sDRDetailsURL;
		$sDRDetailsURL .= "?SessionID=" 		. $objPayClient->getResultField("DigitalReceipt.SessionId");
		$sDRDetailsURL .= "&MerchantID=" 		. $objPayClient->getResultField("DigitalReceipt.MerchantId");
		$sDRDetailsURL .= "&PurchaseAmount=" 	. $objPayClient->getResultField("DigitalReceipt.PurchaseAmountInteger");
		$sDRDetailsURL .= "&Locale=" 			. $objPayClient->getResultField("DigitalReceipt.Locale");
		$sDRDetailsURL .= "&ReceiptNo=" 		. $objPayClient->getResultField("DigitalReceipt.ReceiptNo");
		$sDRDetailsURL .= "&TransactionNo=" 	. $objPayClient->getResultField("DigitalReceipt.TransactionID");
		$sDRDetailsURL .= "&AcqResponseCode=" 	. $objPayClient->getResultField("DigitalReceipt.AcqResponseCode");
		$sDRDetailsURL .= "&QSIResponseCode=" 	. $objPayClient->getResultField("DigitalReceipt.QSIResponseCode");

#		Finished with the $PayClient object, so nullify it
		$objPayClient->close();

#		Pass control to the Digital Receipt details page
		print "Location:$sDRDetailsURL\n\n";
#		print "<!doctype html public \"-//w3c//dtd html 4.0 transitional//en\">\n";
#		print "<html><head>\n";
#		print "<meta http-equiv=\"REFRESH\" CONTENT=\"0; URL=$sDRDetailsURL\">\n";
#		print "</head><body> &nbsp;\n";

	} else {
#		Finished with the comPayClient object, so nullify it
		$objPayClient->close();

#		Pass control to the error handler
		$sErrorPage = $sErrorPage . "?ErrorCode=" . $nErrorCode;
		$sErrorPage .= "&Exception=" . $sException;
		print "Location:$sErrorPage\n\n";
#		print "<!doctype html public \"-//w3c//dtd html 4.0 transitional//en\">\n";
#		print "<html><head>\n";
#		print "<meta http-equiv=\"REFRESH\" CONTENT=\"0; URL=$sErrorPage\">\n";
#		print "</head><body> &nbsp;\n";
	}


















