#!<<PERL_SRC_DIRECTORY>>
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# NAME
# ==== 
# RP_PayAgain.cgi
#
# PURPOSE
# =======
# This page is for the user to input key transaction details.
#
# These details would ordinarily be determined by the merchant's application.
# The merchant application should save details before processing the payment.
# The details would be updated when (if) the Digital Receipt is received.
#
# PAYMENT CLIENT VERSION
# ======================
# This module is not payment client specific.
#
# REVISION HISTORY
# ================
# v1.0				20 February 2000		Initial version
#
# INPUTS
# ======
#	PurchaseAmount		Purchase Amount (Cents)
#	TransactionNo		Transaction number
#	ReturnURL			Where to send the Digital Receipt to
#
# OUTPUTS
# =======
#	This page passes control to RP.cgi
#
# ========================================================================== -->

# Initialisation
# ==============
	unshift(@INC,'<<PC_PERL_DIRECTORY>>'); # add the qsi Perl dir to find perl stuff

# 	These perl libraries are required to use the mini-rpc mechanism
	require 'PaymentClient.pl';
	require 'url_get.pl';

# 	Output to page header - we are producing an html page
	print "Content-type: text/html\n\n";

#	Load all the form variables into an associative array
#	=====================================================
# 	If the variables are passed using either GET or
#	POST, extract the variables into $buffer
	if ($ENV{REQUEST_METHOD} eq 'GET') {
 		$buffer = $ENV{'QUERY_STRING'};
	} else {
 		read ( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

# 	Move QUERY_STRING values into $variables
	foreach $pair (split(/&/, $buffer)) {
	 	$pair =~ tr/+//;
		($name, $value) = split(/=/, $pair);
#		convert hex to ascii
		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge;
  		$variables{$name} = "$value";
	}

#	Retrieve input variables
	$sTransactionNo	= $variables{"TransactionNo"};

	print "</BODY>\n";
	print "<H1><CENTER>MOTO Digital Order Details - Recurring Payment</CENTER></H1>\n";

	print "<!-- The 'Pay Now!' button submits the form, transferring control -->\n";
	print "<FORM ACTION='/cgi-bin/RP.cgi' METHOD='post'>\n";

	print "<!-- set Locale 'en' = English -->\n";
	print "<INPUT TYPE=hidden NAME='Locale' VALUE='en'>";

	print "<!-- get user input -->\n";
	print "<CENTER><TABLE>	<!--Use a table to keep the form neat on the screen -->\n";

	print "<TR>	<TD>Merchant ID</TD>\n";
	print "<TD><INPUT NAME = 'MerchantID' SIZE='15' VALUE='P0000029'></TD></TR>\n";

	print "<TR>	<TD>Session ID</TD>\n";
	print "<TD><INPUT NAME = 'SessionID' SIZE='15' VALUE='SessionID 1'></TD></TR>\n";

	print "<TR>	<TD>Transaction Number</TD>\n";
	print "<TD><INPUT NAME = 'TransactionNo' SIZE='15' VALUE='$sTransactionNo'></TD></TR>\n";

	print "<TR>	<TD>Purchase Amount (Cents)</TD>\n";
	print "<TD><INPUT NAME = 'PurchaseAmount'  SIZE='15' VALUE='100'></TD></TR>\n";

	print "<TR>	<TD>&nbsp;</TD> <!--blank cell, to help align 'Pay Now!' button -->\n";
	print "<TD align='right'><INPUT TYPE='submit' NAME='SubButL' VALUE='Pay Now!'></TD></TR>\n";

	print "</TABLE></CENTER>\n";
	print "</FORM>\n";
	print "</BODY></HTML>\n";
