#!<<PERL_SRC_DIRECTORY>>
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# NAME
# ====
# RP_Return.cgi
#
# PURPOSE
# =======
# Displays the Digital Receipt details. 
# These details would ordinarily be used to update the original order.
# The merchant application would then present an appropriate receipt.
#
# PAYMENT CLIENT VERSION
# ======================
# This module is not payment client specific.
#
# REVISION HISTORY
# ================
# v0.1				20 January 2000		Initial version
#
# INPUTS
# ======
#	SessionID			Your (unique) identifier for the transaction
#	MerchantID			Your Merchant ID - issued to you by the payment service or bank
#	PurchaseAmount		Purchase Amount (Cents)
#	Locale			Defines the langauge to use when presenting payment pages
#	ReceiptNo			Receipt number - issued by Acquiring bank
#	TransactionNo
#	AcqResponseCode		Acquirer Response Code
#	QSIResponseCode		Summary of Acquirer Response Code
#
# OUTPUTS
# =======
#	None
#
# VARIABLES
# =========
#	variables			Contains all of the local variables being passed
#
# SUB ROUTINES
# ============
# 	DisplayResponse		Determine the resultant to be displayed.
#
# ==========================================================================
#
# Initialisation
# ==============
# Load all the form variables into an associative array, variables
	if ($ENV{REQUEST_METHOD} eq 'GET') {
 		$buffer = $ENV{'QUERY_STRING'};
	} else {
 		read ( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

	foreach $pair (split(/&/, $buffer)) {
	 	$pair =~ tr/+//;
		($name, $value) = split(/=/, $pair);
		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge; # convert hex to ascii
  		$variables{$name} = "$value";
	}

#	Get form varaibles
	$sSessionID		= $variables{"SessionID"};
	$sMerchantID	= $variables{"MerchantID"};
	$sPurchaseAmount	= $variables{"PurchaseAmount"};
	$sLocaleID		= $variables{"Locale"};
	$sReceiptNo		= $variables{"ReceiptNo"};
	$sTransactionNo	= $variables{"TransactionNo"};
	$sQSIResponseCode	= $variables{"QSIResponseCode"};
	$sAcqResponseCode	= $variables{"AcqResponseCode"};

      print "Content-type: text/html\n\n";
      print "<h1><center>Digital Receipt Details</center></h1>\n";
	print "<center>\n";
	print "<table cellpadding='5' border='0' rows = '1' cols='2' width='85%'>\n";
	print "Results\n";

	print "<tr>\n";
	print "<td align='left'>Merchant ID</td>\n";
      print "<td align='left'>$sMerchantID</td>\n";
	print "</tr>\n";

	print "<tr>\n";
	print "<td align='left'>Session ID</td>\n";
	print "<td align='left'>$sSessionID</td>\n";
	print "</tr>\n";

	print "<tr>\n";
	print "<td align='left'>Amount</td>\n";
	print "<td align='left'>$sPurchaseAmount</td>\n";
	print "</tr>\n";

	print "<tr>\n";
	print "<td align='left'>Locale</td>\n";
      print "<td align='left'>$sLocaleID</td>\n";
	print "</tr>\n";

	print "<tr>\n";
	print "<td align='left'>Receipt Number</td>\n";
      print "<td align='left'>$sReceiptNo</td>\n";
	print "</tr>\n";

	print "<tr>\n";
	print "<td><hr></td><td><hr></td>\n";
	print "</tr>\n";

	print "<tr>\n";
	print "<td align='left'>TransactionNo</td>\n";
      print "<td align='left'>$sTransactionNo</td>\n";
	print "</tr>\n";

	print "<tr>\n";
	print "<td align='left'>Acquirer Response Code</td>\n";
      print "<td align='left'>$sAcqResponseCode</td>\n";
	print "</tr>\n";

	print "<tr>\n";
	print "<td align='left'>QSI Response Code</td>\n";
      print "<td align='left'>$sQSIResponseCode</td>\n";
	print "</tr>\n";

	print "<tr>\n";
	print "<td align='left'>QSI </td>\n";
      print "<td align='left'>";
	DisplayResponse($sQSIResponseCode);
	print "</td>\n";
	print "</tr>\n";

	print "<FORM ACTION='./RP_PayAgain.cgi' METHOD='post'>\n";
	print "<INPUT TYPE=hidden NAME='TransactionNo' VALUE='$sTransactionNo'\n";
	print "<TR>	<TD></td> <!-- blank cell -->\n";
	print "<TD><INPUT TYPE='submit' NAME='SubButL' VALUE='Pay Again!'></TD></TR>\n";
	print "</FORM>";

	print "</table>\n";
	print "</center>\n";

sub DisplayResponse {
	if ($sQSIResponseCode eq "0") {
	     print "Transaction Successful";
	} elsif ($sQSIResponseCode eq "1") {
           print "Unknown Error";
	} elsif ($sQSIResponseCode eq "2") {
           print "Bank Declined Transaction";
	} elsif ($sQSIResponseCode eq "3") {
           print "No Reply from Bank";
	} elsif ($sQSIResponseCode eq "4") {
           print "Expired Card";
	} elsif ($sQSIResponseCode eq "5") {
           print "Insufficient funds";
	} elsif ($sQSIResponseCode eq "6") {
           print "Error Communicating with Bank";
	} elsif ($sQSIResponseCode eq "7") {
           print "Payment Server System Error";
	} elsif ($sQSIResponseCode eq "8") {
           print "Transaction Type Not Supported";
	} else {
           print "Unable to be determined";
      }
}
