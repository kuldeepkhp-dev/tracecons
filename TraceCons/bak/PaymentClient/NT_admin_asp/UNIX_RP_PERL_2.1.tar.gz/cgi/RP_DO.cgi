#!<<PERL_SRC_DIRECTORY>>
# ----- Copyright --------------------------------------------------------
# (c)2000 Copyright QSI Payments, Inc. - All Rights Reserved
# Copyright Statement: http://www.qsipayments.com/copyright/Payment_Client
# ------------------------------------------------------------------------
#
# NAME
# ====
# RP_DO.cgi
#
# PURPOSE
# ======= 
# Creates a Digital Order and sends it to the Payment Server.
#
# PAYMENT CLIENT VERSION
# ======================
# This module assumes v1.1.54 of the payment client.
#
# REVISION HISTORY
# ================
# v0.1				07 January 2000		Initial version
#
# INPUTS
# ======
#	SessionID			Your (unique) identifier for the transaction
#	MerchantID			Your Merchant ID - issued to you by the payment service or bank
#	PurchaseAmount		Purchase Amount (Cents)
#	LocaleID			Defines the langauge to use when presenting payment pages
#	ReturnURL			Where to send the Digital Receipt to
#
# OUTPUTS
# =======
#	If no errors detected
#		DigitalOrder	Sent to Payment Server (via browser redirection)
#	Else
#		ErrorCode		Sent to sErrorPage (via browser redirection)
#		Exception		Returns Payment Client Exception (where generated)
#
#	ErrorCode Values
#	================
#	10	Payment Client has not initialised correctly.
#		- Check the installation of the payment client.
#	11	Digital Order has not created correctly.
#		- Check input parameters.
#
# VARIABLES
# =========
#	objPayClient		Payment Client object
#	sDigitalOrder		Digital Order string
#	sErrorPage			Name of Error Handler
#	nErrorCode 			Error Code number
#	sException			Payment Client Exception (where generated)
#	variables			Contains all of the local variables being passed
#
# ==========================================================================
#
# Initialisation
# ==============

	unshift(@INC,'<<PC_PERL_DIRECTORY>>'); # add the qsi Perl dir to find perl stuff

# 	These perl libraries are required to use the mini-rpc mechanism
	require 'PaymentClient.pl';
	require 'url_get.pl';

#	Load all the form variables into an associative array
#	=====================================================
# 	If the variables are passed using either GET or
#	POST, extract the variables into $buffer
	if ($ENV{REQUEST_METHOD} eq 'GET') {
 		$buffer = $ENV{'QUERY_STRING'};
	} else {
 		read ( STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}

# 	Move QUERY_STRING values into $variables
	foreach $pair (split(/&/, $buffer)) {
	 	$pair =~ tr/+//;
		($name, $value) = split(/=/, $pair);
#		convert hex to ascii
		$value =~ s/%(\w\w)/sprintf("%c", hex($1))/ge;
  		$variables{$name} = "$value";
	}

#	Define the error constants
	$Error = 0;
	$ERR_PayClient 	= 10;
	$ERR_DigitalOrder	= 11;
	$Recurring_Payment = "1";

#	Initialise ErrorCode - set to No Errors
	$nErrorCode = "";
	$sException	= "";

#	Define Error Handler
	$sErrorPage = "./RP_Order_Error.cgi";

#	Retrieve input variables from the prior form
	$sSessionID		= $variables{"SessionID"};
	$sMerchantID	= $variables{"MerchantID"};
	$sPurchaseAmount	= $variables{"PurchaseAmount"};
	$sLocale		= $variables{"Locale"};
	$sReturnURL		= $variables{"ReturnURL"};
	$sRecurringMode 	= $variables{"RecurringMode"};

# 	because perl interprets the '$' character as a variable declarator,
# 	substitute the $ with a \$ so that perl interprets it as a literal $ character
	$sReturnURL =~ s/$/\$/;

# Create Payment Client Object
# ============================
#	Create Payment Client object
	$objPayClient = new PaymentClient;
#	Open a payment client session
	$sTemp = $objPayClient->open();

#	Test the Payment Client object created corectly
	if ($objPayClient->echo("Test") ne "echo:Test") {
		$nErrorCode = $ERR_PayClient;
	}

# Generate Digital Order
# ======================
#	if no errors ...
	if ($nErrorCode eq "") {
#		Initialise Digital Order
#	 	if recurring payment add Recurring Mode
		if ($sRecurringMode eq $Recurring_Payment) {
			$sTemp = $objPayClient->addDigitalOrderField("RecurMode", $sRecurringMode)
		}
#		Initialise Digital Order
		$sDigitalOrder = $objPayClient->getDigitalOrder($sSessionID, $sMerchantID, $sPurchaseAmount, $sLocale, $sReturnURL);
#		Check for errors
		if ($sDigitalOrder eq $Error) {
			# Failed
			$nErrorCode = $ERR_DigitalOrder;
			$sException	= $sDigitalOrder;
		}
	}

#	Nullify the Payment Client object
	$objPayClient->close();

# Send Digital Order
# ==================
#	if no errors ...
	if ($nErrorCode eq "") {
# 		Serve redirect page - this sends the customer to the payment server page
		print "Location:$sDigitalOrder\n\n";
	}
	else {
#		Pass control to the error handler
		$sErrorPage = $sErrorPage . "?ErrorCode=" . $nErrorCode;
		$sErrorPage .= "&Exception=" . $sException;
		print "Location:$sErrorPage\n\n";
	}





































