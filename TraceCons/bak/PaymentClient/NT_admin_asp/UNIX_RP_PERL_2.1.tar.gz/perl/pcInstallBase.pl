## Record the input parameters
$cgiPath = $ARGV[0];
$perlPath = $ARGV[1];

## Get a list of entries in the perl directory
opendir (@filenames, "./perl");
@directory = readdir (@DIRHANDLE);

## If any entry has a .pl extension, then convert instances of variable to actual value
foreach $filename (@directory) {

	if ($filename =~ /.pl$/) {
	
		open (CONVERT, "perl/$filename");
		open (TMP, ">tmp.dat");

		while (<CONVERT>) {

			$line = $_;
			$line =~ s/<<PERL_SRC_DIRECTORY>>/$cgiPath/;
			$line =~ s/<<PC_PERL_DIRECTORY>>/$perlPath/;
			print TMP $line;
		}

		close CONVERT;
		close TMP;

		open (TMP, "tmp.dat");
		open (CONVERT, ">perl/$filename");

		while (<TMP>) {
			print CONVERT $_;
		}

		close CONVERT;
		close TMP;
	}
}


## Get a list of entries in the cgi directory
opendir (@filenames, "./cgi");
@directory = readdir (@DIRHANDLE);

## If any entry has a .cgi extension, then convert instances of variable to actual value
foreach $filename (@directory) {

	if ($filename =~ /.cgi$/) {
	
		open (CONVERT, "cgi/$filename");
		open (TMP, ">tmp.dat");

		while (<CONVERT>) {

			$line = $_;
			$line =~ s/<<PERL_SRC_DIRECTORY>>/$cgiPath/;
			$line =~ s/<<PC_PERL_DIRECTORY>>/$perlPath/;
			print TMP $line;
		}

		close CONVERT;
		close TMP;

		open (TMP, "tmp.dat");
		open (CONVERT, ">cgi/$filename");

		while (<TMP>) {
			print CONVERT $_;
		}

		close CONVERT;
		close TMP;
	}
}
