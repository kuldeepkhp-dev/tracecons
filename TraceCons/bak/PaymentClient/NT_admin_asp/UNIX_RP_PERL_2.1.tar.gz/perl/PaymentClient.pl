package PaymentClient;
#!<<PERL_SRC_DIRECTORY>>

#
# Copyright 1999 QSI Payments, Inc.
# All rights reserved.  This precautionary copyright notice against
# inadvertent publication is neither an acknowledgement of publication,
# nor a waiver of confidentiality.
#
# QSI Payment Client mini-RPC Perl API
# Contains all functions so that Perl can access the QSI Payment Client
# via the mini-RPC mechanism
#
# Identification:
# $Id: PaymentClient.pl,v 1.4 2000/05/09 03:28:50 jeremym Exp $

require 'sock.pl';
use MIME::Base64;

# Configuartion Variables - You can modify these values
$port     = "9050";      # QSI Payment Client Service Port Number
$timeout = 100;          # Time out period

# Do not modify these values
$returnCode = "0";       # Return Code
$hostname = "127.0.0.1"; # Always local host since it's a local loopback call
$terminator = '\n';      # Marhsalled message terminator


#############################################################################
#
# new - Intantiates an instance of the Payment Client Object
#
# @return Reference to payment client object

sub new {
	my $class = shift;
    my $worker = { socketId=> undef,
                   returnCode=> undef,
                 };
    bless($worker);
    
    return($worker);   		
}



#############################################################################
#
# open - Open a Payment Client mini-RPC session
#
# @return 1 on success or 0 on failure

sub open {
	my $self = shift;
  	$self->{socketId} = &sock'open($hostname,$port);
  		
  	if($self->{socketId} eq "0") {
   		return(0);
  	}
 	return(1);	
}

#############################################################################
#
# close - Close a Payment Client mini-RPC session
#
# @argument RPCSessionId - Session to destroy
#
sub close {
	#$session = $_[0];
 	my $self = shift;

	print $session "99\n"; # Shutdown message for mini-RPC
 	&sock'close($self->{socketId});
}


#############################################################################
#
# echo - Simply echos whatever parameter is given
#
# @argument EchoString - A string to echo
#
# @return Echoed string , result code should be 1 on success 0 on failure

sub echo {
 	my $self = shift;

 	$session = $self->{socketId};

	# Marshall echo message
 	$echoString = $_[0];

 	print $session "1,$_[0]\n";
 	
 	return &socketListen;
}


#############################################################################
#
#  getDigitalOrder - Creates a digital Order
#
# @argument SessionId  Sessiod Id for Transaction
# @argument MerchantId  Merchant Id
# @argument Amount  Amount of Purchase
# @argument Locale  Merhcant Locale
# @argument DR_URL  Digital Receipt Return URL
#
# @return  	0 on failure
#			DO on success

sub getDigitalOrder {
	 		
	my $self = shift;

 	$session = $self->{socketId};
 	
 	# Marshall digital order message 
 	print $session "2,$_[0],$_[1],$_[2],$_[3],$_[4]\n";

 	return &socketListen;
}

#############################################################################
#
# decryptDigitalReceipt - Decrypts an encrypted Digital Receipt
#
# @argument EncryptedDigitalReceipt - The Encrypted Digital Receipt
#
# @return  	0 on failure
#			1 on success with resultField containing a decrypted Digital Receipt

sub decryptDigitalReceipt {
	my $self = shift;

 	$session = $self->{socketId};
 	
	# Marshall processDigitalOrder message
 	print $session "3,$_[0]\n";
 	
 	return &socketListen; 	
}


#############################################################################
#
#  sendMOTODigitalOrder - sends a MOTOdigital Order
#
# @argument SessionId  Sessiod Id for Transaction
# @argument MerchantId  Merchant Id
# @argument Amount  Amount of Purchase
# @argument Locale  Merhcant Locale
# @argument DR_URL  Digital Receipt Return URL
#
# @return  	0 on failure 
#			1 on success with resultField containing a digitalReceipt


sub sendMOTODigitalOrder {	 		
	my $self = shift;
 	$session = $self->{socketId};

 	# Marshall MOTO digital order message
    print $session "6,$_[0],$_[1],$_[2],$_[3],$_[4]\n";
    
    return &socketListen;
}

#############################################################################
#
# addDigitalOrderField 	add additional fields to a digital order - used 
#						specifically by the extended(MOTO) digital order
#
# @argument Field Name - String containing the field name to add
# @argument Field value - String containing the field value to add
#
# @return 	0 upon failure
#			1 upon success

sub addDigitalOrderField {	
	my $self = shift;		
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "7,$_[0],$_[1]\n";
		
	return &socketListen;	
}


#############################################################################
#
# doSETWakeupMessageUsingFile
#
# @argument Field sessionId
# @argument Field purchAmount
# @argument Field currencyCode
# @argument Field currencyExponent
# @argument Field orderDescription
# @argument Field lidm
# @argument Field setURL
# @argument Field configFile
#
# @return 	0 upon failure
#			1 upon success

sub doSETWakeupMessageUsingFile {
	my $self = shift;
	$session = $self->{socketId};

	# Marshall new field message and send it to the socket
	print $session "8,$_[0],$_[1],$_[2],$_[3],";
	print $session "$_[4],$_[5],$_[6]\n";


	while (1) {
  		$_ = &sock'read($session, $timeout);

  		$result = $_;

  		last if $result =~ /\n/;
  		last if &sock'eof;
  		last if &sock'timeout;
 	}

	($self->{returnCode},$result) = split(",",$result);
 	$result =~ s/\n//o;
}


#############################################################################
#
# doSETWakeupMessage
#
# @argument Field host
# @argument Field port
# @argument Field sessionId
# @argument Field posURL
# @argument Field posMain
# @argument Field merchantId
# @argument Field payType
# @argument Field transType
# @argument Field purchAmount
# @argument Field currencyCode
# @argument Field currencyExponent
# @argument Field orderDescriptionType
# @argument Field orderDescription
# @argument Field lidm
# @argument Field setURL
# @argument Field successURL
# @argument Field failureURL

#
# @return 	0 upon failure
#			1 upon success

sub doSETWakeupMessage {
	my $self = shift;

	$session = $self->{socketId};

	#Marshall new field message
	print $session "9,$_[0],$_[1],$_[2],$_[3],";
	print $session "$_[4],$_[5],$_[6],$_[7],";
	print $session "$_[8],$_[9],$_[10],$_[11],";
	print $session "$_[12],$_[13],$_[14],$_[15],$_[16]\n";


	while (1) {
  		$_ = &sock'read($session, $timeout);

  		$result = $_;


  		last if $result =~ /\n/;
  		last if &sock'eof;
  		last if &sock'timeout;
 	}

	($self->{returnCode},$result) = split(",",$result);
 	$result =~ s/\n//o;
}


#############################################################################
#
# doSETTransactionUsingFile
#
# @argument Field sessionID
# @argument Field configFile
# @argument Field bufferLength
# @argument Field inBuffer
#
# @return 	0 upon failure
#			1 upon success

sub doSETTransactionUsingFile {
	my $self = shift;

	$session = $self->{socketId};

    # binary parameter to be sent - therefore have to use binary write methods
    # embed the doSETTransactionUsingFile method call in the binary preparation
    # message
    

    
    # MIME encode the message to enable easier message handling and to eliminate
    # Perl interpretation of control characters et cetera.
    
    $binData = encode_base64($_[3]); 
    
    @binMessage = split(/\n/, $binData);
    $binDataSize = 0;
    foreach $line(@binMessage) {
    	$binDataSize += length($line);	
    }
    
 	# prepare the binary method
 	print $session "97,10,$_[0],$_[1],$binDataSize\n";

    foreach $line (@binMessage) {    	
    	#print $session "98, 1, $line\n";	    	
    	print $session "98,$line\n";
	}
	
	
    while (1) {
  		$_ = &sock'read($session, $timeout);

  		$result = $_;

  		last if $result =~ /\n/;
  		last if &sock'eof;
  		last if &sock'timeout;
 	}

	($self->{returnCode},$result) = split(",",$result);
 	$result =~ s/\n//o;
}

#############################################################################
#
# doSETTransaction
#
# @argument Field host
# @argument Field port
# @argument Field merchantId
# @argument Field shopId
# @argument Field bufferSize
# @argument Field inBuffer
#
# @return 	0 upon failure
#			1 upon success

sub doSETTransaction {
	my $self = shift;

	$session = $self->{socketId};


    # binary parameter to be sent - therefore have to use binary write methods
    # embed the doSETTransaction method call in the binary preparation
    # message

    
    # MIME encode the message to enable easier message handling and to eliminate
    # Perl interpretation of control characters et cetera.
    
    $binData = encode_base64($_[5]); 
    
    @binMessage = split(/\n/, $binData);
    $binDataSize = 0;
    foreach $line(@binMessage) {
    	$binDataSize += length($line);	
    }
    
    
    # prepare the binary method
 	print $session "97,11,$_[0],$_[1],$_[2],$_[3],$binDataSize\n";
 	
 	
 	foreach $line (@binMessage) {    	
    	print $session "98,$line\n";
	}

    
    while (1) {
  		$_ = &sock'read($session, $timeout);

  		$result = $_;

  		last if $result =~ /\n/;
  		last if &sock'eof;
  		last if &sock'timeout;
 	}

	($self->{returnCode},$result) = split(",",$result);
 	$result =~ s/\n//o;
}

#############################################################################
#
# getResultFieldBuffer - Get a Result Field Element
#
# @argument Field - String of the field you want to access
#
# @return Value of the field requested

sub getResultFieldBuffer {
	my $self = shift;

	$session = $self->{socketId};
 	$resultField = $_[0];
 	print $session "12,$_[0]\n"; # Field to retrieve

    # because the Result field buffer is a binary
 	$_ = &sock'read($session, $timeout);
 	$len = $_;

    # remove leading zeros - otherwise it may be treated as an octal value
    $len =~ s/^0*//;

    # remove the newline character from the end
    chop $len;
 	$buf = "";
    $cumulativeLength = 0;


    # Read the socket messages until the cumulative message length is equal to
    # length ($len) provided by the previous message. Because the Perl socket
    # library uses the newline character '\n' to terminate socket messages,
    # the source of the message is split by the occurrences of the newline
    # character OR 1024 bytes - which ever comes first. If the newline character
    # in the source file is the reason for the message being sent
    # ($termSwitch == '1'), then the newline character at the end of the message
    # is maintained. If the socket message being sent is not the cause of a
    # newline character in the source message (either 1024 bytes or end of file),
    # then the messages newline character is removed.
    # The buffer ($buf) is the result of the series of messages being
    # concatenated.

    while (1) {
        $socketMessage = &sock'read($session, $timeout);

        $termSwitch = substr($socketMessage, 0, 1);
        $message = substr($socketMessage, 1);

        if ($termSwitch == '0') {
            $message = substr($message, 0, length($message) - 1);
        }

        $cumulativeLength += length($message);
        $buf .= $message;

        # exit the loop once the cumulativeLength reaches the expected length
        last if ($len == $cumulativeLength);
 	}

    # only want to return the message, not the prefixed status flag and
    # separating comma.
    $result = substr($buf, 2);
}

#############################################################################
#
# getVersion - gets the full version number of the Payment Client
#
# @return Value of the field requested or 0 for failure

sub getVersion {
	
	my $self = shift;	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "13\n";
	
	return &socketListen;
}


# Administration methods - the format is the same for each - argument numbers
# differ depending upon the method signature as per the PaymentClientThread
# class.
#############################################################################
                
sub doAdminCapture {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "14,$_[0],$_[1],$_[2],$_[3],$_[4]\n";
	
	return &socketListen;
}
                    
#############################################################################
                    
sub doAdminRefund {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "15,$_[0],$_[1],$_[2],$_[3],$_[4]\n";
	
	return &socketListen;
	
}
#############################################################################

sub doAdminVoidCapture {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "16,$_[0],$_[1],$_[2],$_[3]\n";
	
	return &socketListen;
}
#############################################################################
sub doAdminVoidRefund {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "17,$_[0],$_[1],$_[2],$_[3]\n";	
	
	return &socketListen;
}

#############################################################################
                    
sub doAdminFinancialTransactionHistory {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session	"18,$_[0],$_[1],$_[2],$_[3]\n";
	
	return &socketListen;
}
#############################################################################
                
sub doAdminShoppingTransactionHistory {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "19,$_[0],$_[1],$_[2],$_[3],$_[4]\n";	
	
	return &socketListen;
}

#############################################################################
                
sub doAdminReconciliation {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "20,$_[0],$_[1],$_[2]\n";
	
	return &socketListen;
}

#############################################################################
sub doAdminReconciliationDetail {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "21,$_[0],$_[1],$_[2],$_[3]\n";
	
	return &socketListen;
}

#############################################################################
sub doAdminReconciliationHistory {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "22,$_[0],$_[1],$_[2],$_[3],$_[4]\n";	
	
	return &socketListen;
}




#############################################################################
sub getResultCount {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "23\n";	
	
	return &socketListen;
}



#############################################################################
sub getResultRecord {
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "24,$_[0]\n";
	 	
 	return &socketListen;
}
 

#############################################################################
#
# addDigitalOrderField - Adds a field to the digitalOrder
#
# @argument Field - field name
# @argument Field - field value
#
# @return Value of the field requested or 0 for failure

sub addDigitalOrderField {
	
	my $self = shift;	
	
	$session = $self->{socketId};
	
	#Marshall new field message
	print $session "7,$_[0],$_[1]\n";
	
	
	while (1) {
  		$_ = &sock'read($session, $timeout);
  		
  		$result = $_;
  		
  		last if $result =~ /\n/;
  		last if &sock'eof;
  		last if &sock'timeout;
 	}	
 
	($self->{returnCode},$result) = split(",",$result);	
 	$result =~ s/\n//o;
}




#############################################################################
#
# getResultField - Get a Result Field Element
#
# @argument Field - String of the field you want to access
#
# @return Value of the field requested or 0 for failure

sub getResultField {
	my $self = shift;

	$session = $self->{socketId};
 	#$resultField = $_[0];
 	print $session "4,$_[0]\n"; # Field to retrieve
 	
 	return &socketListen;
}


#############################################################################
#
# nextResult
#
# @return 0 on failure , 1 if the result cursor was positioned

sub nextResult {
	my $self = shift;

 	$session = $self->{socketId};
 	$nextResult = $_[0];	
 	
 	# Marshall processDigitalOrder message
 	print $session "5,null\n";
 	
 	return &socketListen;
 
}


#############################################################################
#
# getReturnCode - Get the last Return Code
#
# @return Return Code for last operation - 1 denotes success , 0 denotes failure

sub getReturnCode {
	my $self = shift;
 	return($self->{returnCode});
}


#############################################################################
# socketListen - waits upon a completed socket message and returns the result
#				to the socketListen calling method

sub socketListen {
	while (1) {
  		$_ = &sock'read($session, $timeout);
  		$result = $_;
  		last if $result =~ /\n/;
  		last if &sock'eof;
  		last if &sock'timeout;
 	}
 	
 	($self->{returnCode},@result) = split(",",$result);

 	if ($self->{returnCode} == 0) {
 		$result = 0;
 	} else {
 		# The following code handles $results that actually contain 
 		# commas and hence "re-constitute" the  result. It also
 		# handles $results that contain no commas too - it's just 
 		# complicated by the need to handle commas.
 		$result = "";
 		foreach $item (@result) {
 			if ($item ne $result[$#result]) {
 				$result = $result.$item.",";	
 			} else {
 				$result = $result.$item;	
 			}
 		}	
 	}
 	$result =~ s/\n//o;
 	return $result;
}
          
                              