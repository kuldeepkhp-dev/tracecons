#!<<PERL_SRC_DIRECTORY>>
package sock;

# USAGE:
# ======
#
# To open a connection to a socket:
#
#	$handle = &sock'open($hostname, $port) || die $!;
#	# hostname & port can each be either a name or a number
#
# Read and write the same as with any other file handle:
#
#	print $handle "hello, socket\n";
#	$response = <$handle>;
#
# To close cleanly:
#
#	&sock'close($handle);
#
# To close all open sockets, in case of an emergency exit:
#
#	&sock'close_all;
#
# AUTHOR: 	QSI Payments using stuff from David Noble (dnoble@ufo.jpl.nasa.gov) 
#		   	and Prof. Golden G. Richard III, Dept. of Computer Science, 
#			University of New Orleans, April 1996-March 1998 - thanks to the 
#			Profi for tips on fixing Solaris issues. The bulk of the rest of 
#			it is David Noble's work from way back on 11 Feb 1993.
# DATE:	   22-May-2000
#
#############################################################################

use Socket;

sub SOL_SOCKET		{ 65535; }
sub SO_REUSEADDR	{ 4; }

# Get system-specific socket parameters, make assumptions if necessary.

$status = 'ok';

$sockaddr_t = 'S n a4 x8';

# Seed the generation of names for file handles.
$latest_handle = 'sock0000000001';

sub open {
  local ($remote_host, $remote_port) = @_;
  if (!$remote_port) {
    $! = "bad arguments to sock'open()";
    return 0;
  }
  $sock = ++$latest_handle;

  # Look up the port if it was specified by name instead of by number.
  if ($remote_port =~ /\D/o) {
    ($name,$aliases,$remote_port) = getservbyname($remote_port,'tcp');
  }

  # Look up the address if it was specified by name instead of by number.
  if ($remote_host =~ /\D/o) {
    ($name,$aliases,$type,$len,$remote_addr) = gethostbyname($remote_host);
  } else {
    $remote_addr = $remote_host;
  }

  # Make the socket structures.
  $this = pack($sockaddr_t, AF_INET, 0, "\0\0\0\0");
  $remote_sock = pack($sockaddr_t, AF_INET, $remote_port, $remote_addr);

  # Make the socket filehandle.
  ($name,$aliases,$proto) = getprotobyname('tcp');
  socket($sock, AF_INET, SOCK_STREAM, $proto) || return 0;

  # Set up the port so it's freed as soon as we're done.
  setsockopt($sock, &SOL_SOCKET, &SO_REUSEADDR, 1);

  # Bind this socket to an address.
  bind($sock, $this) || return 0;

  # Call up the remote socket.
  connect($sock,$remote_sock) || return 0;

  $handles{$sock} = 1;
  $oldfh = select($sock); $| = 1; select($oldfh);
  return "sock'" . $sock;
}

sub close {
  local ($sock) = shift(@_) || return 0;
  shutdown ($sock, 2);
  delete $handles{$sock};
}

sub close_all {
  for $sock (keys %handles) {
    shutdown ($sock, 2);
    delete $handles{$sock};
  }
}

$status = 'ok';

sub read {
	
    local ($handle) = shift (@_);
    local ($endtime) = shift (@_);
    local ($rmask, $nfound, $nread, $thisbuf);
    local ($multilines) = $*;
    local ($buf) == '';
    $status = 'ok';
    $* = 1; # this gets restored to its previous value before returning

    if (!$SocketBuffer{$handle}) {
      $endtime += time;
      get_data: while ($endtime > time) {
	$rmask = "";
	$thisbuf = "";
	vec($rmask, fileno($handle), 1) = 1;
	($nfound, $rmask) = select($rmask, undef, undef, $endtime - time);
	if ($nfound) {
	    $nread = sysread($handle, $thisbuf, 1024);
	    if ($nread > 0) {
		$SocketBuffer{$handle} .= $thisbuf;
	
		last get_data if &_preprocess($handle) && !$multilines;
	    }
	    else {
		$status = 'eof';
		return ''; # connection closed
	    }
	}
	else {
	    $status = 'timeout';
	    last get_data;
	}
      }
    }

    if ($SocketBuffer{$handle}) {
	if (!$multilines && ($SocketBuffer{$handle} =~ m/\n/o)) {
	    $SocketBuffer{$handle} =~ s/^(.*\n)//o; 
	    $buf = $1; 
	}
	else {
	    $buf = $SocketBuffer{$handle};
	    $SocketBuffer{$handle} = '';
	}
}

    $* = $multilines;
    $buf;    
}


sub ok { $status eq 'ok'; }
sub eof { $status eq 'eof'; } 
sub timeout { $status eq 'timeout'; }
sub status { $status; }

sub _preprocess {
    local ($handle) = shift(@_);
    local ($_) = $SocketBuffer{$handle};


    $SocketBuffer{$handle} = $_;
    m/\n/o; # return value: whether there is a full line or not
}
